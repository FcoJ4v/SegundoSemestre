package com.duoc.clases;

import java.text.DecimalFormat;

/**
 *
 * @author Christian Sarmiento
 * @version v1.0
 * @since 07 de septiembre, 2020
 */
public class Empleado {
    
    /*
        Atributos 
    */
    private String rut;
    private String nombre;
    private String apellido;
    private char sexo;
    private int edad;
    private final int SUELDO_BASE = 320500;
    private boolean vigente;
    private String email;

    /*
        Constructures (default y por parámetros
    */    
    public Empleado() {
    }

    public Empleado(String rut, String nombre, String apellido, char sexo, int edad, boolean vigente) {
        this.rut = rut;
        this.nombre = nombre;
        this.apellido = apellido;
        this.sexo = sexo;
        this.edad = edad;
        this.vigente = vigente;
        crearEmail();
    }
    
    /*
        Accesadores y Mutadores (sin validación)
    */
    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public boolean isVigente() {
        return vigente;
    }

    public void setVigente(boolean vigente) {
        this.vigente = vigente;
    }

    public String getEmail() {
        return email;
    }

    private void setEmail(String email) {
        this.email = email;
    }
    
    /*
        Métodos custom
    */
    public void crearEmail(){
        String aux_nombre = "";
        if (nombre.length() <= 2)
        {
            aux_nombre = nombre;
        }
        else
        {
            aux_nombre = nombre.substring(0,3);
        }
        this.email = (aux_nombre + apellido + 
                rut.substring(rut.length()-4, rut.length()-2) +
                "@miempresa.com").toLowerCase();
    }
    
    public int obtenerSueldo(int horas){
        int sueldo = 0;
        if (horas <= 180)
        {
            sueldo = horas * 10000 + SUELDO_BASE;
        }
        else
        {
            sueldo = (180 * 10000) + ((horas - 180) * 10000 * 2) + SUELDO_BASE;
        }
        return sueldo;
    }
    
    public String informacionEmpleado(){
        DecimalFormat formatoRut = new DecimalFormat("###,###");
        int numeroRut = Integer.parseInt(rut.substring(0,rut.length()-2));
        String dv = rut.substring(rut.length()-1);
        String contratado = "Si";
        if (vigente == false)
        {
            contratado = "No";
        }
        String informacion = 
                "Rut: " + formatoRut.format(numeroRut)+ "-" + dv + "\n" +
                "Nombre: " + nombre + " " + apellido + "\n" + 
                "Contratado: " + contratado + "\n" + 
                "Email: " + email + "\n"; 
        return informacion;
    }
    
    
    
    
    
    
}
