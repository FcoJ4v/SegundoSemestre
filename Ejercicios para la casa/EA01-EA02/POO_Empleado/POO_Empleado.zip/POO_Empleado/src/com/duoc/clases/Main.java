package com.duoc.clases;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        DecimalFormat formatoSueldo = new DecimalFormat("$ ###,###");
        Scanner lector = new Scanner(System.in);
        
        Empleado e1 = new Empleado("12345678-K", "Aquiles", "Bailo", 'f', 25, true);
        System.out.print(e1.informacionEmpleado());
        System.out.println("Sueldo : " + formatoSueldo.format(e1.obtenerSueldo(156)));
        
        Empleado e2 = new Empleado("15345876-5","Cindy","Nero",'f',28,false);
        System.out.println("****************************");
        System.out.println(e2.informacionEmpleado());
        
        System.out.println("****************************");
        System.out.println("Bienvenidos al Sistema de Registro de Empleados");
        System.out.print("Ingrese RUT [Ej. 12345678-9]: ");
        String rut = lector.next();
        System.out.print("Ingrese nombre [Ej. Aquiles]: ");
        String nombre = lector.next();
        System.out.print("Ingrese apellido [Ej. Baeza]: ");
        String apellido = lector.next();
        System.out.print("Ingrese género [m | f]: ");
        char genero = lector.next().charAt(0);
        System.out.print("Ingrese edad: ");
        int edad = lector.nextInt();        
        Empleado e3 = new Empleado(rut,nombre,apellido,genero,edad,true);        
        System.out.print("Ingresa la cantidad de horas que registró este mes: ");
        int horas = lector.nextInt();
        System.out.println("****************************");
        System.out.print(e3.informacionEmpleado());
        System.out.println("Sueldo: " + formatoSueldo.format(e3.obtenerSueldo(horas)));       
        
        
    }
    
}
