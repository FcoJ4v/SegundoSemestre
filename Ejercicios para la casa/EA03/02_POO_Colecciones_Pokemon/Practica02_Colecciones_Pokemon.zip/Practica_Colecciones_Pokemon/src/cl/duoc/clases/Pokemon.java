package cl.duoc.clases;

public class Pokemon implements Comparable<Pokemon>{
    
    private String zona;
    private int numero;
    private String nombre;
    private String sexo;
    private String tipo;
    private int poder;
    private double peso;
    private double altura;
    private int[] stats;

    public Pokemon() {
    }

    public Pokemon(String zona, int numero, String nombre, String sexo, String tipo, int poder, double peso, double altura, int[] stats) {
        this.zona = zona;
        this.numero = numero;
        this.nombre = nombre;
        this.sexo = sexo;
        this.tipo = tipo;
        this.poder = poder;
        this.peso = peso;
        this.altura = altura;
        this.stats = stats;
    }

    public String getZona() {
        return zona;
    }

    public void setZona(String zona) {
        this.zona = zona;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getPoder() {
        return poder;
    }

    public void setPoder(int poder) {
        this.poder = poder;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public int[] getStats() {
        return stats;
    }

    public void setStats(int[] stats) {
        this.stats = stats;
    }

  @Override
    public String toString() {
        return "Pokemon{" + "zona=" + zona + ", numero=" + numero + ", nombre=" + nombre 
                + ", sexo=" + sexo + ", tipo=" + tipo + ", poder=" + poder + ", peso=" + peso 
                + "Kg. , altura=" + altura + "mts. , Estadísticas= A" + stats[0] + "- D"+ stats[1] + "- S" + stats[2] + '}';
    }

    @Override
    public int compareTo(Pokemon o) {
        int comparacionByNumero = this.numero - o.getNumero();
        if(comparacionByNumero != 0)
        {
            return this.numero - o.getNumero();
        }
        int comparacionByPoder = this.poder - o.getPoder();
        if(comparacionByPoder != 0)
        {
            return this.poder - o.getPoder();
        }
        int comparacionBySexo = this.sexo.compareToIgnoreCase(o.getSexo());
        if(comparacionBySexo != 1)
        {
            return this.sexo.compareToIgnoreCase(o.getSexo());
        }
        return ((stats[0] + stats[1] + stats[2]) / 3) - ((o.getStats()[0] + o.getStats()[1] + o.getStats()[2]) / 3);
    }
    
    
    
}
