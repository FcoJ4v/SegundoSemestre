package cl.duoc.clases;

import java.util.ArrayList;
import java.util.Collections;

public class MochilaPokemon {
    
    //Atributos
    private ArrayList<Pokemon> pokemon;

    
    //Constructor
    public MochilaPokemon() {
        pokemon = new ArrayList<>();
    }

    //Getters y Setters
    public ArrayList<Pokemon> getPokemon() {
        return pokemon;
    }

    public void setPokemon(ArrayList<Pokemon> pokemon) {
        this.pokemon = pokemon;
    }
    
    //Métodos CUSTOM
    public void registrarPokemon(Pokemon p){
        pokemon.add(p);
    }
    
    public ArrayList<Pokemon> buscarPokemon(String caracteristica){
        ArrayList<Pokemon> resultados = new ArrayList<>();
        for (Pokemon p : pokemon) 
        {
            if(p.toString().toLowerCase().contains(caracteristica.toLowerCase()))
            {
                resultados.add(p);
            }
        }
        return resultados;
    }
    
    
    public int transferirPokemon(String nombre){
        int transferidos = 0;
        for (int i = pokemon.size() - 1 ; i >= 0 ; i--) 
        {
            if(pokemon.get(i).getNombre().equalsIgnoreCase(nombre))
            {
                    transferidos++;
                    pokemon.remove(i);
            }
        }        
        return transferidos;
    }
    
    public ArrayList<Pokemon> ordenarListadoPokemon(){
        Collections.sort(pokemon);
        return pokemon;
    }
    
    
    
}
