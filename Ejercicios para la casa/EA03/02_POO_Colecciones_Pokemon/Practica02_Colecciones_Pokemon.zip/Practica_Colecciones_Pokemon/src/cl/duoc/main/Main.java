package cl.duoc.main;

import cl.duoc.clases.MochilaPokemon;
import cl.duoc.clases.Pokemon;

public class Main {

    public static void main(String[] args) {
        MochilaPokemon m = new MochilaPokemon();
        Pokemon p1 = new Pokemon("Kanto", 1, "Bulbasaur", "Masculino", "Planta/Veneno", 860, 7, 0.7, new int[]{15,15,15});
        Pokemon p2 = new Pokemon("Kanto", 1, "Bulbasaur", "Femenino", "Planta/Veneno", 135, 5.5, 0.4, new int[]{12,10,15});
        Pokemon p3 = new Pokemon("Kanto", 147, "Dratini", "Femenino", "Dragón", 455, 10, 1.2, new int[]{12,10,15});
        Pokemon p4 = new Pokemon("Kanto", 20, "Rattata", "Femenino", "Normal", 635, 2.4, 0.2, new int[]{12,10,15});
        Pokemon p5 = new Pokemon("Kanto", 16, "Pidgey", "Masculino", "Normal", 135, 2.6, 0.4, new int[]{12,10,15});
        Pokemon p6 = new Pokemon("Kanto", 4, "Charmander", "Femenino", "Fuego", 465, 8.5, 0.6, new int[]{14,14,14});
        Pokemon p7 = new Pokemon("Kanto", 4, "Charmander", "Masculino", "Fuego", 213, 8, 0.4, new int[]{12,10,15});
        Pokemon p8 = new Pokemon("Kanto", 109, "Koffing", "N/A", "Veneno", 720, 1, 0.4, new int[]{7,10,10});
        Pokemon p9 = new Pokemon("Kanto", 129, "Magikarp", "Masculino", "Agua", 119, 10, 0.9, new int[]{15,15,15});
        Pokemon p10 = new Pokemon("Kanto", 129, "Magikarp", "Masculino", "Agua", 165, 10, 0.9, new int[]{13,12,15});
        m.registrarPokemon(p1);
        m.registrarPokemon(p2);
        m.registrarPokemon(p3);
        m.registrarPokemon(p4);
        m.registrarPokemon(p5);
        m.registrarPokemon(p6);
        m.registrarPokemon(p7);
        m.registrarPokemon(p8);
        m.registrarPokemon(p9);
        m.registrarPokemon(p10);
        
        for (Pokemon p: m.buscarPokemon("veneno")) 
        {
            System.out.println(p);
        }
        
        
        System.out.println(m.transferirPokemon("bulbasaur"));
        System.out.println(m.getPokemon().size());
        m.ordenarListadoPokemon();
        
        for (Pokemon p: m.getPokemon()) 
        {
            System.out.println(p);
        }
        
    }
    
}
