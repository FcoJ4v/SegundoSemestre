package clases;

import java.util.ArrayList;
import java.util.Collections;

public class Contenedor {
    
    private int id;
    private double capacidadMaxima;
    private ArrayList<Encomienda> encomiendas;

    public Contenedor(int id, double capacidadMaxima) {
        this.id = id;
        this.capacidadMaxima = capacidadMaxima;
        encomiendas = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getCapacidadMaxima() {
        return capacidadMaxima;
    }

    public void setCapacidadMaxima(double capacidadMaxima) {
        this.capacidadMaxima = capacidadMaxima;
    }

    public ArrayList<Encomienda> getEncomiendas() {
        return encomiendas;
    }

    public void setEncomiendas(ArrayList<Encomienda> encomiendas) {
        this.encomiendas = encomiendas;
    }
    
    
    
    public Encomienda buscarEncomienda(int codigo){
        for (Encomienda encomienda : encomiendas) 
        {
            if(encomienda.getId() == codigo)
            {
                return encomienda;
            }
        }
        return null;
    }
    
    public boolean registraEncomienda(Encomienda e){
        if(buscarEncomienda(e.getId()) == null && (capacidadMaxima - pesoTotalAcumulado()) >= e.getPeso())
        {
            encomiendas.add(e);
            return true;
        }
        return false;
    }
    
    public boolean modificarEncomienda(Encomienda e){
        for (Encomienda encomienda : encomiendas) 
        {
            if(encomienda.getId() == e.getId())
            {
                encomienda.setPaisDestino(e.getPaisDestino());
                encomienda.setCiudadDestino(e.getCiudadDestino());
                encomienda.setPeso(e.getPeso());
                encomienda.setValorDeclaradoUSD(e.getValorDeclaradoUSD());
                return true;
            }
        }
        return false;
    }
    
    public boolean bajarEncomienda(int codigo){
        for (Encomienda encomienda : encomiendas) 
        {
            if(encomienda.getId() == codigo)
            {
                encomiendas.remove(encomienda);
                return true;
            }
        }
        return false;
    }
    
    public ArrayList<Encomienda> bajarEncomiendas(String ciudadDestino){
        ArrayList<Encomienda> bajados = new ArrayList<>();
        for (int i = encomiendas.size() - 1; i >= 0 ; i--) 
        {
            if(encomiendas.get(i).getCiudadDestino().equalsIgnoreCase(ciudadDestino))
            {
                bajados.add(encomiendas.get(i));
                encomiendas.remove(i);
            }
            
        }
        return null;
    }
    
    public double montoTotalDeclarado(double valorDolar){
        double montoTotal = 0.0;
        for (Encomienda encomienda : encomiendas) 
        {
            montoTotal += encomienda.valorCLP(valorDolar);
        }
        return montoTotal;
    }
    
    public double pesoTotalAcumulado(){
        double acumPeso = 0;
        for (Encomienda encomienda : encomiendas) 
        {
            acumPeso += encomienda.getPeso();
        }
        return acumPeso;
    }
    
    public ArrayList<Encomienda> listarEncomiendasOrdenadas(){
        Collections.sort(encomiendas);
        return encomiendas;
    }

    @Override
    public String toString() {
        return "Contenedor: " + id + " | Capacidad: " + pesoTotalAcumulado() + " / " + capacidadMaxima 
                + " | Cantidad Encomiendas: " + encomiendas.size();
    }
    
    
    
}
