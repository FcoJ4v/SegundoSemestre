package clases;

public class Encomienda  implements Comparable<Encomienda>{
    
    private int id;
    private String paisDestino;
    private String ciudadDestino;
    private double peso;
    private double valorDeclaradoUSD;

    public Encomienda() {
    }

    public Encomienda(int id, String paisDestino, String ciudadDestino, double peso, double valorDeclaradoUSD) {
        this.id = id;
        this.paisDestino = paisDestino;
        this.ciudadDestino = ciudadDestino;
        this.peso = peso;
        this.valorDeclaradoUSD = valorDeclaradoUSD;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPaisDestino() {
        return paisDestino;
    }

    public void setPaisDestino(String paisDestino) {
        this.paisDestino = paisDestino;
    }

    public String getCiudadDestino() {
        return ciudadDestino;
    }

    public void setCiudadDestino(String ciudadDestino) {
        this.ciudadDestino = ciudadDestino;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getValorDeclaradoUSD() {
        return valorDeclaradoUSD;
    }

    public void setValorDeclaradoUSD(double valorDeclaradoUSD) {
        this.valorDeclaradoUSD = valorDeclaradoUSD;
    }

    public double valorCLP(double valorUSD){
        return valorDeclaradoUSD * valorUSD;
    }
    
    @Override
    public String toString() {
        return "Encomienda: " + id + " | País Destino: " + paisDestino 
                + " | Ciudad Destino: " + ciudadDestino + " | Peso: " + peso 
                + " | Valor Declarado USD: " + valorDeclaradoUSD + " USD";
    }

    @Override
    public int compareTo(Encomienda o) {
        int comparacionByPaisDestino = paisDestino.compareToIgnoreCase(o.getPaisDestino());
        if(comparacionByPaisDestino != 0)
        {
            return comparacionByPaisDestino;
        }
        
        int comparacionByCiudadDestino = ciudadDestino.compareToIgnoreCase(o.getCiudadDestino());
        if(comparacionByCiudadDestino != 0)
        {
            return comparacionByCiudadDestino;
        }
        
        int comparacionByPeso = Double.compare(peso, o.getPeso());
        if(comparacionByPeso != 0)
        {
            return comparacionByPeso;
        }
        
        int comparacionByValorDeclaradoUSD = Double.compare(valorDeclaradoUSD, o.getValorDeclaradoUSD());
        if(comparacionByValorDeclaradoUSD != 0)
        {
            return comparacionByValorDeclaradoUSD;
        }
        
        return this.id - o.getId();
    }
    
    
    
}
