package clases;

public class Carguero {
    
    private int id;
    private String nombre;
    private String nacionalidad;
    private Contenedor[] contenedores;

    public Carguero(int id, String nombre, String nacionalidad, int cantidadContendores) {
        this.id = id;
        this.nombre = nombre;
        this.nacionalidad = nacionalidad;
        contenedores = new Contenedor[cantidadContendores];
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public Contenedor[] getContenedores() {
        return contenedores;
    }

    public void setContenedores(Contenedor[] contenedores) {
        this.contenedores = contenedores;
    }

    public boolean subirContenedor(Contenedor nuevo){
        if(buscarContenedor(nuevo.getId()) == null)
        {
            for (int i = 0; i < contenedores.length; i++) 
            {
                if(contenedores[i] == null)
                {
                    contenedores[i] = nuevo;
                    return true;
                }
            }
        }
        return false;
    }
    
    public Contenedor buscarContenedor(int id){
        for (int i = 0; i < contenedores.length; i++) 
        {
            if(contenedores[i] != null)
            {
                if(contenedores[i].getId() == id)
                {
                    return contenedores[i];
                }
            }
        }
        return null;
    }
    
    public boolean bajarContenedor(int id){
        for (int i = 0; i < contenedores.length; i++) 
        {
            if(contenedores[i].getId() == id)
            {
                contenedores[i] = null;
                return true;
            }
        }
        return false;
    }
    
    /**
     * Método que permite establecer la cantidad de contenedores que hay 
     * realmente en el carguero.
     * @return int
     */
    public int contenedoresAlmacenados(){
        int contadorContenedores = 0;
        for (int i = 0; i < contenedores.length; i++) 
        {
            if(contenedores[i] != null)
            {
                contadorContenedores++;
            }
        }
        return contadorContenedores;
    }
    
    @Override
    public String toString() {
        return "Carguero:" + id + " | Nombre: " + nombre + " | País: " + nacionalidad +
                " | Nro. de contenedores: " + contenedoresAlmacenados() + " / " + contenedores.length;
    }
    
    
    
}
