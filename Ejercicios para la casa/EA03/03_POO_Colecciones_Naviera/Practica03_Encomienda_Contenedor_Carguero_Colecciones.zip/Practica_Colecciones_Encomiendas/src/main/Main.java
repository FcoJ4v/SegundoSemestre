package main;

import clases.Carguero;
import clases.Contenedor;
import clases.Encomienda;
import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {
        Carguero c = new Carguero(1010, "Nautilus", "Chile", 10);
        Contenedor con = new Contenedor(1111, 2000);
        Encomienda e1 = new Encomienda(100001, "Chile", "Santiago", 20, 130);
        Encomienda e2 = new Encomienda(100002, "Chile", "Santiago", 250, 1500);
        Encomienda e3 = new Encomienda(100003, "Chile", "Rancagua", 100, 140);
        Encomienda e4 = new Encomienda(100004, "Chile", "Santiago", 50, 130);
        Encomienda e5 = new Encomienda(100005, "Chile", "Valparaíso", 70, 130);
        Encomienda e6 = new Encomienda(100006, "Chile", "Santiago", 10, 130);
        Encomienda e7 = new Encomienda(100007, "Chile", "Valparaíso", 10, 130);
        Encomienda e8 = new Encomienda(100008, "Chile", "Valparaíso", 150, 1000);
        Encomienda e9 = new Encomienda(100009, "Chile", "Santiago", 300, 15000);
        Encomienda e10 = new Encomienda(100010, "Chile", "Santiago", 20, 130);
        
        con.registraEncomienda(e1);
        con.registraEncomienda(e2);
        con.registraEncomienda(e3);
        con.registraEncomienda(e4);
        con.registraEncomienda(e5);
        con.registraEncomienda(e6);
        con.registraEncomienda(e7);
        con.registraEncomienda(e8);
        con.registraEncomienda(e9);
        con.registraEncomienda(e10);
        c.subirContenedor(con);
        System.out.println(c);
        
        System.out.println(con + " | Monto Total Declarado: $ " + (int)con.montoTotalDeclarado(740));
        
        
    }
    
}
