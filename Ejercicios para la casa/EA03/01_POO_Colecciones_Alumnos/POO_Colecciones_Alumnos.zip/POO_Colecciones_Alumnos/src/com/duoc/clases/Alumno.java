package com.duoc.clases;

public class Alumno {
    
    //atributos
    private String rut;
    private String nombre;
    private String apellido;
    private double[] notas;

    //constructores
    public Alumno() {
    }

    public Alumno(String rut, String nombre, String apellido, double[] notas) {
        this.rut = rut;
        this.nombre = nombre;
        this.apellido = apellido;
        this.notas = notas;
    }

    //Getter y Setters
    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if(nombre.trim().length() >= 3 && nombre.trim().length() <= 30)
        {
            this.nombre = nombre.trim();
        }
        else
        {
            System.out.println("El nombre debe tener entre 3 y 30 caracteres");
        }
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        if(apellido.trim().length() >= 3 && apellido.trim().length() <= 30)
        {
            this.apellido = apellido.trim();
        }
        else
        {
            System.out.println("El apellido debe tener entre 3 y 30 caracteres");
        }        
    }

    public double[] getNotas() {
        return notas;
    }

    public void setNotas(double[] notas) {
        this.notas = notas;
    }
    
    //métodos custom
    
    /**
     * Este método permite obtener el promedio final del alumno. El cual se 
     * obtendrá a partir de la suma de todas las notas dividido por la 
     * cantidad de notas.
     * @return double
     */
    public double promedioFinal(){
        double acumNotas = 0;
        for(int i=0; i < notas.length; i++)
        {
            acumNotas += notas[i];
        }
        return (acumNotas / notas.length * 10.0) / 10.0;
    }
    
    /**
     * Este método permite establecer la situación final del alumno según 
     * su promedio final.
     * Si el promedio final es mayor o igual a 3.95 implica que el alumno ha 
     * aprobado y por lo tanto el método retornará TRUE. De lo contrario, 
     * es decir, si el promedio final del alumno es menor a 3.95 el alumno ha 
     * reprobado y el método retornará FALSE.
     * 
     * @return boolean
     */
    public boolean situacionFinal(){
        if(promedioFinal() >= 3.95)
        {
            return true;
        }
        return false;
    }

    /**
     * 
     * @return 
     */
    @Override
    public String toString() {
        String situacion = "Reprobado";
        if(situacionFinal())
        {
            situacion = "Aprobado";
        }
        return  "Rut: " + rut + 
                " | Nombre: " + nombre + " " + apellido + 
                " | Promedio Final: " + promedioFinal() + 
                " | Situación final: " + situacion;
    }
    
    
    
    
}
