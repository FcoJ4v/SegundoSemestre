package com.duoc.clases;

public class Main {
    
    public static void main(String[] args) {
        double[] notasA1 = {4.5, 5.5, 6.0 , 3.0};
        Alumno a1 = new Alumno("1-9", "Armando", "casas",notasA1);
        
        System.out.println(a1);
    }
}
