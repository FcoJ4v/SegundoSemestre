package com.duoc.models;

import com.duoc.statics.utils.Validaciones;
import java.util.Date;

public class Empleado {
    
    private String rut;
    private String nombre;
    private String apellido;
    private String genero;
    private String email;
    private Date fecha_contrato;
    private int sueldo;
    private int id_cargo;

    public Empleado() {
    }

    public Empleado(String rut, String nombre, String apellido, String genero, String email, Date fecha_contrato, int sueldo, int id_cargo) throws CustomException {
        this.setRut(rut);
        this.setNombre(nombre);
        this.apellido = apellido;
        this.genero = genero;
        this.setEmail(email);
        this.fecha_contrato = fecha_contrato;
        this.sueldo = sueldo;
        this.id_cargo = id_cargo;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) throws CustomException {
        if(new Validaciones().validarRut(rut) == false){
            throw new CustomException("Rut no válido.");
        }
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) throws CustomException {
        if(nombre.trim().length() == 0){
            throw new CustomException("Debes ingresar un nombre válido.");
        }
        else if(nombre.trim().length() > 30){
            throw new CustomException("Cantidad de caracteres excedida (30)");
        }
        else{
            this.nombre = nombre;
        }
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) throws CustomException {
        if(new Validaciones().validarEmail(email) == false){
            throw new CustomException("Email no válido.");
        }
        else if(email.trim().length() > 100){
            throw new CustomException("Cantidad de caracteres excedida (100)");
        }
        else{
            this.email = email;
        }
    }

    public Date getFecha_contrato() {
        return fecha_contrato;
    }

    public void setFecha_contrato(Date fecha_contrato) {
        this.fecha_contrato = fecha_contrato;
    }

    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) {
        this.sueldo = sueldo;
    }

    public int getId_cargo() {
        return id_cargo;
    }

    public void setId_cargo(int id_cargo) {
        this.id_cargo = id_cargo;
    }
    
    
    
    
    
}
