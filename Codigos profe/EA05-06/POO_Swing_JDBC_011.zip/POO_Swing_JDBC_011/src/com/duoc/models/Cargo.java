package com.duoc.models;

public class Cargo {

    private int id_cargo;
    private String descripcion;

    public Cargo() {
    }

    public Cargo(int id_cargo, String descripcion) throws CustomException {
        setId_cargo(id_cargo);
        setDescripcion(descripcion);
    }

    public int getId_cargo() {
        return id_cargo;
    }

    public void setId_cargo(int id_cargo) throws CustomException {
        if(id_cargo < 1000 || id_cargo > 9999){
            throw new CustomException("Código ingresado no válido.");
        }
        this.id_cargo = id_cargo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) throws CustomException {
        if(descripcion.isEmpty() || descripcion.trim().length() == 0){
            throw new CustomException("Debes ingresar una descripción válida.");
        }
        else if(descripcion.trim().length() > 100){
            throw new CustomException("La cantidad de caracteres ingresado excede el máximo permitido(100).");
        }
        else{
            this.descripcion = descripcion;
        }        
    }
    
    @Override
    public String toString(){
        return descripcion;
    }
    
    
    
}
