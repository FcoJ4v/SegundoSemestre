package com.duoc.controllers;

import com.duoc.conexion.Conexion;
import com.duoc.models.Cargo;
import com.duoc.models.CustomException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CargoController implements iCrud<Cargo>{
    
    //Definir las sentencias SQL que se ejecutaran contra el servidor...
    private static final String SQL_INSERT = "INSERT INTO CARGO (ID_CARGO,DESCRIPCION) VALUES (?,?)";
    private static final String SQL_READ = "SELECT * FROM CARGO WHERE ID_CARGO = ?";
    private static final String SQL_UPDATE = "UPDATE CARGO SET DESCRIPCION = ? WHERE ID_CARGO = ?";
    private static final String SQL_DELETE = "DELETE FROM CARGO WHERE ID_CARGO = ?";
    private static final String SQL_READ_ALL = "SELECT * FROM CARGO ORDER BY ID_CARGO ASC";
    private static final String SQL_MAX_ID = "SELECT MAX(ID_CARGO) FROM CARGO";
    
    //Definir el objeto conexion usando el patrón singleton para conectarnos a la BBDD.
    private static final Conexion CONEXION = Conexion.getEstadoConexion();
    
    //Definir un objeto que nos permitir preparar y ejecutar una consulta.
    private PreparedStatement ps;
    
    //Definir un objeto que nos permita almacenar el resultado de la ejecución de una consulta
    private ResultSet rs;
    
    @Override
    public boolean create(Cargo t) {
        try {
            ps = CONEXION.getConexion().prepareStatement(SQL_INSERT);
            ps.setInt(1, t.getId_cargo());
            ps.setString(2, t.getDescripcion());
            return ps.executeUpdate() > 0;
        } 
        catch (SQLException ex) {
            return false;
        }
        finally {
            CONEXION.closeConexion();
        }
    }

    @Override
    public Cargo read(Object key) {
        try {
            Cargo c = null;
            ps = CONEXION.getConexion().prepareStatement(SQL_READ);
            ps.setInt(1, (int)key);
            rs = ps.executeQuery();
            if(rs.next()){
                c = new Cargo(rs.getInt(1), rs.getString(2));
            }
            return c;
        } catch (SQLException | CustomException ex) {
            return null;
        }
        finally {
            CONEXION.closeConexion();
        }
    }

    @Override
    public boolean update(Cargo t) {
        try {
            ps = CONEXION.getConexion().prepareStatement(SQL_UPDATE);            
            ps.setString(1, t.getDescripcion());
            ps.setInt(2, t.getId_cargo());
            return ps.executeUpdate() > 0;
        } 
        catch (SQLException ex) {
            return false;
        }
        finally {
            CONEXION.closeConexion();
        }
    }

    @Override
    public boolean delete(Object key) {
        try {
            ps = CONEXION.getConexion().prepareStatement(SQL_DELETE); 
            ps.setInt(1, (int) key);
            return ps.executeUpdate() > 0;
        } 
        catch (SQLException ex) {
            return false;
        }
        finally {
            CONEXION.closeConexion();
        }
    }

    @Override
    public ArrayList<Cargo> readAll() {
        try {
            ArrayList<Cargo> cargos = new ArrayList<>();
            ps = CONEXION.getConexion().prepareStatement(SQL_READ_ALL);
            rs = ps.executeQuery();
            while(rs.next()){
                cargos.add(new Cargo(rs.getInt(1), rs.getString(2)));
                        
            }
            return cargos;
        } catch (SQLException | CustomException ex) {
            return null;
        }
        finally {
            CONEXION.closeConexion();
        }
    }
    
    public int getMaxIdCargo(){
        try {
            ps = CONEXION.getConexion().prepareStatement(SQL_MAX_ID);
            rs = ps.executeQuery();
            int id = 0;
            if(rs.next()){
                id = rs.getInt(1);
            }
            if(id < 999){
                id += 1000;
            }
            return id+1;
        } catch (SQLException e) {
            return -1;
        }
        finally{
            CONEXION.closeConexion();
        }
    }
    
    
}
