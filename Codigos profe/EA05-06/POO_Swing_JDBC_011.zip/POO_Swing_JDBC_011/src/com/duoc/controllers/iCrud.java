package com.duoc.controllers;

import java.util.ArrayList;

public interface iCrud<T> {
    
    //CRUD
    public boolean create(T t);
    public T read(Object key);
    public boolean update(T t);
    public boolean delete(Object key);
    
    public ArrayList<T> readAll();
    
}
