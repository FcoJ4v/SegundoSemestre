package com.duoc.controllers;

import com.duoc.conexion.Conexion;
import com.duoc.models.Empleado;
import com.duoc.models.CustomException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

public class EmpleadoController implements iCrud<Empleado>{
    
    //Definir las sentencias SQL que se ejecutaran contra el servidor...
    private static final String SQL_INSERT = "INSERT INTO EMPLEADO (RUT,NOMBRE,APELLIDO,GENERO,EMAIL,FECHA_CONTRATO,SUELDO,ID_CARGO) VALUES (?,?,?,?,?,?,?,?)";
    private static final String SQL_READ = "SELECT * FROM EMPLEADO WHERE RUT = ?";
    private static final String SQL_UPDATE = "UPDATE EMPLEADO SET NOMBRE = ?, APELLIDO = ?, GENERO = ?, EMAIL = ?, FECHA_CONTRATO = ?, SUELDO = ?, ID_CARGO = ? WHERE RUT = ?";
    private static final String SQL_DELETE = "DELETE FROM EMPLEADO WHERE RUT = ?";
    private static final String SQL_READ_ALL = "SELECT * FROM EMPLEADO ORDER BY APELLIDO ASC";
    
    
    //Definir el objeto conexion usando el patrón singleton para conectarnos a la BBDD.
    private static final Conexion CONEXION = Conexion.getEstadoConexion();
    
    //Definir un objeto que nos permitir preparar y ejecutar una consulta.
    private PreparedStatement ps;
    
    //Definir un objeto que nos permita almacenar el resultado de la ejecución de una consulta
    private ResultSet rs;
    
    @Override
    public boolean create(Empleado t) {
        try {
            ps = CONEXION.getConexion().prepareStatement(SQL_INSERT);
            ps.setString(1, t.getRut());
            ps.setString(2, t.getNombre());
            ps.setString(3, t.getApellido());
            ps.setString(4, t.getGenero());
            ps.setString(5, t.getEmail());
            ps.setDate(6, (Date) t.getFecha_contrato());
            ps.setInt(7, t.getSueldo());
            ps.setInt(8, t.getId_cargo());
            return ps.executeUpdate() > 0;
        } 
        catch (SQLException ex) {
            return false;
        }
        finally {
            CONEXION.closeConexion();
        }
    }

    @Override
    public Empleado read(Object key) {
        try {
            Empleado e = null;
            ps = CONEXION.getConexion().prepareStatement(SQL_READ);
            ps.setString(1, key.toString());
            rs = ps.executeQuery();
            if(rs.next()){
                e = new Empleado(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getDate(6), rs.getInt(7), rs.getInt(8));
            }
            return e;
        } catch (SQLException | CustomException ex) {
            return null;
        }
        finally {
            CONEXION.closeConexion();
        }
    }

    @Override
    public boolean update(Empleado t) {
        try {
            ps = CONEXION.getConexion().prepareStatement(SQL_UPDATE);      
            ps.setString(1, t.getNombre());
            ps.setString(2, t.getApellido());
            ps.setString(3, t.getGenero());
            ps.setString(4, t.getEmail());
            ps.setDate(5, (Date) t.getFecha_contrato());
            ps.setInt(6, t.getSueldo());
            ps.setInt(7, t.getId_cargo());
            ps.setString(8, t.getRut());
            return ps.executeUpdate() > 0;
        } 
        catch (SQLException ex) {
            return false;
        }
        finally {
            CONEXION.closeConexion();
        }
    }

    @Override
    public boolean delete(Object key) {
        try {
            ps = CONEXION.getConexion().prepareStatement(SQL_DELETE); 
            ps.setString(1, key.toString());
            return ps.executeUpdate() > 0;
        } 
        catch (SQLException ex) {
            return false;
        }
        finally {
            CONEXION.closeConexion();
        }
    }

    @Override
    public ArrayList<Empleado> readAll() {
        try {
            ArrayList<Empleado> empleados = new ArrayList<>();
            ps = CONEXION.getConexion().prepareStatement(SQL_READ_ALL);
            rs = ps.executeQuery();
            while(rs.next()){
                empleados.add(new Empleado(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getDate(6), rs.getInt(7), rs.getInt(8)));
                        
            }
            return empleados;
        } catch (SQLException | CustomException ex) {
            return null;
        }
        finally {
            CONEXION.closeConexion();
        }
    }
    
}

