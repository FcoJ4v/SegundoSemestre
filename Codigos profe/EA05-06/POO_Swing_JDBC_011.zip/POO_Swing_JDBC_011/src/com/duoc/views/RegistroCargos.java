/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package com.duoc.views;

import com.duoc.controllers.CargoController;
import com.duoc.models.Cargo;
import com.duoc.models.CustomException;
import java.awt.HeadlessException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class RegistroCargos extends javax.swing.JInternalFrame {

    private static CargoController CC = new CargoController();
    
    
    public RegistroCargos() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelCodigoCargo = new javax.swing.JLabel();
        jLabelDescripcionCargo = new javax.swing.JLabel();
        jTextFieldCodigoCargo = new javax.swing.JTextField();
        jTextFieldDescripcionCargo = new javax.swing.JTextField();
        jButtonRegistrarCargo = new javax.swing.JButton();
        jButtonModificarCargo = new javax.swing.JButton();
        jButtonLimpiarFormularioCargos = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableListadoCargos = new javax.swing.JTable();

        setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        setClosable(true);
        setTitle("Administrador Cargos");
        setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/com/duoc/statics/img/settings_24x24.png"))); // NOI18N
        addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentRemoved(java.awt.event.ContainerEvent evt) {
                formComponentRemoved(evt);
            }
        });
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameClosed(evt);
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameOpened(evt);
            }
        });
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        jLabelCodigoCargo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelCodigoCargo.setText("Código");

        jLabelDescripcionCargo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelDescripcionCargo.setText("Descripción");

        jTextFieldCodigoCargo.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jTextFieldDescripcionCargo.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jButtonRegistrarCargo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/duoc/statics/img/plus_24x24.png"))); // NOI18N
        jButtonRegistrarCargo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButtonRegistrarCargo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRegistrarCargoActionPerformed(evt);
            }
        });

        jButtonModificarCargo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/duoc/statics/img/edit.png"))); // NOI18N
        jButtonModificarCargo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButtonModificarCargo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonModificarCargoActionPerformed(evt);
            }
        });

        jButtonLimpiarFormularioCargos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/duoc/statics/img/refresh_24x24.png"))); // NOI18N
        jButtonLimpiarFormularioCargos.setToolTipText("");
        jButtonLimpiarFormularioCargos.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButtonLimpiarFormularioCargos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLimpiarFormularioCargosActionPerformed(evt);
            }
        });

        jTableListadoCargos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Descripción"
            }
        ));
        jTableListadoCargos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableListadoCargosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableListadoCargos);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabelDescripcionCargo, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                                .addComponent(jLabelCodigoCargo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jButtonRegistrarCargo, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(jButtonModificarCargo, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                                .addComponent(jButtonLimpiarFormularioCargos, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jTextFieldCodigoCargo)
                            .addComponent(jTextFieldDescripcionCargo))))
                .addContainerGap(31, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelCodigoCargo, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextFieldCodigoCargo, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDescripcionCargo, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextFieldDescripcionCargo, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonLimpiarFormularioCargos, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButtonModificarCargo, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButtonRegistrarCargo, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(69, 69, 69))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        limpiarFormularioCargos();
        MainWindow.mw.habilitarMenuRegistroCargos(false);
    }//GEN-LAST:event_formComponentShown

    private void jButtonRegistrarCargoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRegistrarCargoActionPerformed
        registrarCargo();
    }//GEN-LAST:event_jButtonRegistrarCargoActionPerformed

    private void jButtonModificarCargoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonModificarCargoActionPerformed
        modificarCargo();
    }//GEN-LAST:event_jButtonModificarCargoActionPerformed

    private void jTableListadoCargosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableListadoCargosMouseClicked
        cargarDatosCargoSeleccionado();
    }//GEN-LAST:event_jTableListadoCargosMouseClicked

    private void jButtonLimpiarFormularioCargosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonLimpiarFormularioCargosActionPerformed
        limpiarFormularioCargos();
    }//GEN-LAST:event_jButtonLimpiarFormularioCargosActionPerformed

    private void formComponentRemoved(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_formComponentRemoved
        MainWindow.mw.habilitarMenuRegistroCargos(true);
    }//GEN-LAST:event_formComponentRemoved

    private void formInternalFrameOpened(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameOpened
        MainWindow.mw.habilitarMenuRegistroCargos(false);
    }//GEN-LAST:event_formInternalFrameOpened

    private void formInternalFrameClosed(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameClosed
        MainWindow.mw.habilitarMenuRegistroCargos(true);
    }//GEN-LAST:event_formInternalFrameClosed
    
    private void registrarCargo(){
        try 
        {
            int id_cargo = Integer.parseInt(this.jTextFieldCodigoCargo.getText());
            String descripion = this.jTextFieldDescripcionCargo.getText();
            Cargo c = new Cargo(id_cargo, descripion);
            if(CC.create(c)){
                JOptionPane.showMessageDialog(null, "Cargo creado satisfactoriamente","Mensajes",JOptionPane.INFORMATION_MESSAGE);
                limpiarFormularioCargos();
                if(MainWindow.reg_empleados.isVisible()){
                    MainWindow.reg_empleados.cargarListadoCargos();
                }
                if(MainWindow.info_empleados.isVisible()){
                    MainWindow.info_empleados.cargarListadoCargos();
                }
            }
            else{
                JOptionPane.showMessageDialog(null, "No se pudo registrar el nuevo cargo.","Mensajes",JOptionPane.ERROR_MESSAGE);
                
            }
        } 
        catch (CustomException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(),"Mensajes",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void modificarCargo(){
        try 
        {
            int id_cargo = Integer.parseInt(this.jTextFieldCodigoCargo.getText());
            String descripion = this.jTextFieldDescripcionCargo.getText();
            Cargo c = new Cargo(id_cargo, descripion);
            if(CC.update(c)){
                JOptionPane.showMessageDialog(null, "Cargo modificado satisfactoriamente","Mensajes",JOptionPane.INFORMATION_MESSAGE);
                limpiarFormularioCargos();
                if(MainWindow.reg_empleados.isVisible()){
                    MainWindow.reg_empleados.cargarListadoCargos();
                }
                if(MainWindow.info_empleados.isVisible()){
                    MainWindow.info_empleados.cargarListadoCargos();
                }
            }
            else{
                JOptionPane.showMessageDialog(null, "No se pudo modificar el cargo.","Mensajes",JOptionPane.ERROR_MESSAGE);
                
            }
        } 
        catch (CustomException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(),"Mensajes",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void cargarNuevoIdCargo(){
        try{
            int id_cargo = CC.getMaxIdCargo();
            if(id_cargo > 0){
                this.jTextFieldCodigoCargo.setText(String.valueOf(id_cargo));
            }
            else{
                JOptionPane.showMessageDialog(null, "Problemas con la base de datos.","Mensajes",JOptionPane.ERROR_MESSAGE);
            }
        }
        catch(HeadlessException ex){
            JOptionPane.showMessageDialog(null, "Problemas desconocidos.\n" + ex.getMessage(),"Mensajes",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void cargarTablaCargos(){
        try{
            ArrayList<Cargo> cargos = CC.readAll();
            DefaultTableModel modelo = new DefaultTableModel();
            modelo.addColumn("Código");
            modelo.addColumn("Descripción");
            for(Cargo c: cargos){
                Object[] fila = new Object[2];
                fila[0] = c.getId_cargo();
                fila[1] = c.getDescripcion();
                modelo.addRow(fila);
            }
            this.jTableListadoCargos.setModel(modelo);
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, "Problemas desconocidos.\n" + ex.getMessage(),"Mensajes",JOptionPane.ERROR_MESSAGE);
        }
    }
     
    private void cargarDatosCargoSeleccionado(){
        try{
            int fila = this.jTableListadoCargos.getSelectedRow();
            int id_cargo = Integer.parseInt(this.jTableListadoCargos.getModel().getValueAt(fila, 0).toString());
            Cargo c = CC.read(id_cargo);
            if(c != null){
                this.jTextFieldCodigoCargo.setText(String.valueOf(c.getId_cargo()));
                this.jTextFieldDescripcionCargo.setText(c.getDescripcion());
                this.jTextFieldDescripcionCargo.requestFocus();
                this.jTextFieldDescripcionCargo.selectAll();
            }
            else{
                JOptionPane.showMessageDialog(null, "No se encontró el cargo buscado!!!","Mensajes",JOptionPane.ERROR_MESSAGE);
            }
        }
        catch(HeadlessException ex){
            JOptionPane.showMessageDialog(null, "Problemas desconocidos.\n" + ex.getMessage(),"Mensajes",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void limpiarFormularioCargos(){
        cargarNuevoIdCargo();
        cargarTablaCargos();
        this.jTextFieldDescripcionCargo.setText(null);
        this.jTextFieldDescripcionCargo.requestFocus();
        this.jTextFieldDescripcionCargo.selectAll();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonLimpiarFormularioCargos;
    private javax.swing.JButton jButtonModificarCargo;
    private javax.swing.JButton jButtonRegistrarCargo;
    private javax.swing.JLabel jLabelCodigoCargo;
    private javax.swing.JLabel jLabelDescripcionCargo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableListadoCargos;
    private javax.swing.JTextField jTextFieldCodigoCargo;
    private javax.swing.JTextField jTextFieldDescripcionCargo;
    // End of variables declaration//GEN-END:variables
}
