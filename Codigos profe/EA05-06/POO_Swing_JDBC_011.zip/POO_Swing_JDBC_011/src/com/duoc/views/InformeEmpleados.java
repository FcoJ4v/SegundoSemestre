package com.duoc.views;

import com.duoc.controllers.CargoController;
import com.duoc.controllers.EmpleadoController;
import java.util.ArrayList;
import com.duoc.models.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;


public class InformeEmpleados extends javax.swing.JInternalFrame {
    
    private final EmpleadoController EC = new EmpleadoController();
    private final CargoController CC = new CargoController();
    private boolean permisoEliminar = false;

    public boolean isPermisoEliminar() {
        return permisoEliminar;
    }
    
    public void setPerminoEliminar(boolean permisoEliminar){
        this.permisoEliminar = permisoEliminar;
    }

    public InformeEmpleados() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTableListadoEmpleados = new javax.swing.JTable();
        jButtonReestablecerTablaEmpleados = new javax.swing.JButton();
        jButtonEliminarEmpleado = new javax.swing.JButton();
        jPanelFiltros = new javax.swing.JPanel();
        jTextFieldFiltro = new javax.swing.JTextField();
        jComboBoxListadoCargos = new javax.swing.JComboBox<>();
        jLabelFiltroTextos = new javax.swing.JLabel();
        jLabelFiltroCargos = new javax.swing.JLabel();

        setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        setClosable(true);
        setTitle("Informe Empleados");
        setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/com/duoc/statics/img/graphique_24x24.png"))); // NOI18N
        addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentRemoved(java.awt.event.ContainerEvent evt) {
                formComponentRemoved(evt);
            }
        });
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameClosed(evt);
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameOpened(evt);
            }
        });
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        jTableListadoEmpleados.setAutoCreateRowSorter(true);
        jTableListadoEmpleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Rut", "Nombre", "Email", "Genero", "Cargo", "Fecha Contrato", "Sueldo"
            }
        ));
        jScrollPane1.setViewportView(jTableListadoEmpleados);

        jButtonReestablecerTablaEmpleados.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/duoc/statics/img/refresh_24x24.png"))); // NOI18N
        jButtonReestablecerTablaEmpleados.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButtonReestablecerTablaEmpleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonReestablecerTablaEmpleadosActionPerformed(evt);
            }
        });

        jButtonEliminarEmpleado.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/duoc/statics/img/delete_24x24.png"))); // NOI18N
        jButtonEliminarEmpleado.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButtonEliminarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarEmpleadoActionPerformed(evt);
            }
        });

        jPanelFiltros.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Seleccione el tipo de filtro", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 12))); // NOI18N

        jTextFieldFiltro.setText("Ingrese texto a buscar...");
        jTextFieldFiltro.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextFieldFiltroFocusGained(evt);
            }
        });
        jTextFieldFiltro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldFiltroKeyReleased(evt);
            }
        });

        jComboBoxListadoCargos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxListadoCargosActionPerformed(evt);
            }
        });

        jLabelFiltroTextos.setText("Filtro por texto...");

        jLabelFiltroCargos.setText("Filtro por cargos...");

        javax.swing.GroupLayout jPanelFiltrosLayout = new javax.swing.GroupLayout(jPanelFiltros);
        jPanelFiltros.setLayout(jPanelFiltrosLayout);
        jPanelFiltrosLayout.setHorizontalGroup(
            jPanelFiltrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelFiltrosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelFiltrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelFiltrosLayout.createSequentialGroup()
                        .addComponent(jLabelFiltroTextos, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(125, 125, 125)
                        .addGroup(jPanelFiltrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jComboBoxListadoCargos, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabelFiltroCargos, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)))
                    .addComponent(jTextFieldFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(303, Short.MAX_VALUE))
        );
        jPanelFiltrosLayout.setVerticalGroup(
            jPanelFiltrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelFiltrosLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanelFiltrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabelFiltroCargos, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(jLabelFiltroTextos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelFiltrosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxListadoCargos, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(56, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jButtonReestablecerTablaEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButtonEliminarEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(23, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1)
                            .addComponent(jPanelFiltros, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jPanelFiltros, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButtonReestablecerTablaEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonEliminarEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        cargarTablaEmpleados();
        cargarListadoCargos();
        MainWindow.mw.habilitarMenuInformacionEmpleados(false);
        if(permisoEliminar){
            this.jButtonEliminarEmpleado.setEnabled(true);
        }
        else{
            this.jButtonEliminarEmpleado.setEnabled(false);
        }
   }//GEN-LAST:event_formComponentShown

    private void jButtonReestablecerTablaEmpleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonReestablecerTablaEmpleadosActionPerformed
        cargarTablaEmpleados();
        cargarListadoCargos();
        this.jTextFieldFiltro.setText("Ingrese texto a buscar");
        this.jComboBoxListadoCargos.setSelectedIndex(-1);
        this.jTextFieldFiltro.requestFocus();
    }//GEN-LAST:event_jButtonReestablecerTablaEmpleadosActionPerformed

    private void jButtonEliminarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarEmpleadoActionPerformed
        int fila_seleccionada = this.jTableListadoEmpleados.getSelectedRow();
        String rut = this.jTableListadoEmpleados.getModel().getValueAt(fila_seleccionada, 0).toString();
        int respuesta = JOptionPane.showConfirmDialog(null, "Estas seguro que deseas eliminar al empleado.\nEsta acción es irreversible", "Mensajes", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if(respuesta == JOptionPane.YES_OPTION){
            if(EC.delete(rut)){
            JOptionPane.showMessageDialog(null, "Empleado eliminado satisfactoriamente!!!", "Mensajes", JOptionPane.INFORMATION_MESSAGE);
            cargarTablaEmpleados();
            }
            else{
                JOptionPane.showMessageDialog(null, "Ups, no se logró completar el proceso de eliminación.", "Mensajes", JOptionPane.ERROR_MESSAGE);
                cargarTablaEmpleados();
            }
        }
    }//GEN-LAST:event_jButtonEliminarEmpleadoActionPerformed

    private void formComponentRemoved(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_formComponentRemoved
        MainWindow.mw.habilitarMenuInformacionEmpleados(true);
    }//GEN-LAST:event_formComponentRemoved

    private void formInternalFrameOpened(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameOpened
        MainWindow.mw.habilitarMenuInformacionEmpleados(false);
    }//GEN-LAST:event_formInternalFrameOpened

    private void formInternalFrameClosed(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameClosed
        MainWindow.mw.habilitarMenuInformacionEmpleados(true);
    }//GEN-LAST:event_formInternalFrameClosed

    private void jTextFieldFiltroFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextFieldFiltroFocusGained
        this.jTextFieldFiltro.selectAll();
    }//GEN-LAST:event_jTextFieldFiltroFocusGained

    private void jTextFieldFiltroKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldFiltroKeyReleased
        String filtro = this.jTextFieldFiltro.getText();
        this.cargarTablaEmpleados(filtro);
    }//GEN-LAST:event_jTextFieldFiltroKeyReleased

    private void jComboBoxListadoCargosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxListadoCargosActionPerformed
        if(this.jComboBoxListadoCargos.getSelectedIndex() > -1){
            Cargo c = (Cargo) this.jComboBoxListadoCargos.getSelectedItem();
            int id_cargo = c.getId_cargo();
            cargarTablaEmpleados(id_cargo);
        }
    }//GEN-LAST:event_jComboBoxListadoCargosActionPerformed

    public void cargarTablaEmpleados(){
        try {
            ArrayList<Empleado> empleados = EC.readAll();
            ArrayList<Cargo> cargos = CC.readAll();
            DefaultTableModel modelo = new DefaultTableModel();
            modelo.addColumn("Rut");
            modelo.addColumn("Nombre");
            modelo.addColumn("Email");
            modelo.addColumn("Genero");
            modelo.addColumn("Cargo");
            modelo.addColumn("Fecha Contrato");
            modelo.addColumn("Sueldo");
            for(Empleado e: empleados){
                Object fila[] = new Object[7];
                fila[0] = e.getRut();
                fila[1] = e.getNombre() + " " + e.getApellido();
                fila[2] = e.getEmail();
                fila[3] = e.getGenero().toUpperCase();
                String cargo = "";
                for(Cargo c: cargos){
                    if(c.getId_cargo() == e.getId_cargo()){
                        cargo = c.getDescripcion();
                    }
                }
                fila[4] = cargo;
                fila[5] = new SimpleDateFormat("dd-MM-yyyy").format(e.getFecha_contrato());
                fila[6] = new DecimalFormat("$ #,##0").format(e.getSueldo());
                modelo.addRow(fila);
            }
            this.jTableListadoEmpleados.setModel(modelo);
            this.alinearColumnaTabla(jTableListadoEmpleados, 3, SwingConstants.CENTER);
            this.alinearColumnaTabla(jTableListadoEmpleados, 5, SwingConstants.RIGHT);
            this.alinearColumnaTabla(jTableListadoEmpleados, 6, SwingConstants.RIGHT);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Problemas de conexión con la base de datos.","Mensajes",JOptionPane.ERROR_MESSAGE);
        } 
    }
    
    public void cargarListadoCargos(){
        try {
            ArrayList<Cargo> cargos = CC.readAll();
            DefaultComboBoxModel modelo = new DefaultComboBoxModel();
            for(Cargo c: cargos){
                modelo.addElement(c);
            }
            this.jComboBoxListadoCargos.setModel(modelo);
            this.jComboBoxListadoCargos.setSelectedIndex(-1);
        } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Problemas de conexión con la base de datos.","Mensajes",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void cargarTablaEmpleados(String filtro){
        try {
            ArrayList<Empleado> empleados = EC.readAll();
            ArrayList<Cargo> cargos = CC.readAll();
            DefaultTableModel modelo = new DefaultTableModel();
            modelo.addColumn("Rut");
            modelo.addColumn("Nombre");
            modelo.addColumn("Email");
            modelo.addColumn("Genero");
            modelo.addColumn("Cargo");
            modelo.addColumn("Fecha Contrato");
            modelo.addColumn("Sueldo");
            for(Empleado e: empleados){
                String fecha_contrato = new SimpleDateFormat("dd-MM-yyyy").format(e.getFecha_contrato());
                String cargo = "";
                for(Cargo c: cargos){
                    if(c.getId_cargo() == e.getId_cargo()){
                        cargo = c.getDescripcion();
                    }
                }
                String sueldo = String.valueOf(e.getSueldo());
                String sueldo_formateado = new DecimalFormat("$ #,##0").format(e.getSueldo());
                
                if(e.getRut().toLowerCase().contains(filtro.toLowerCase()) 
                        || e.getNombre().toLowerCase().contains(filtro.toLowerCase())
                        || e.getApellido().toLowerCase().contains(filtro.toLowerCase())
                        || e.getEmail().toLowerCase().contains(filtro.toLowerCase())
                        || e.getGenero().toLowerCase().contains(filtro.toLowerCase())
                        || cargo.toLowerCase().contains(filtro.toLowerCase())
                        || fecha_contrato.toLowerCase().contains(filtro.toLowerCase())
                        || sueldo.toLowerCase().contains(filtro.toLowerCase())
                        || sueldo_formateado.toLowerCase().contains(filtro.toLowerCase())){
                    Object fila[] = new Object[7];
                    fila[0] = e.getRut();
                    fila[1] = e.getNombre() + " " + e.getApellido();
                    fila[2] = e.getEmail();
                    fila[3] = e.getGenero().toUpperCase();

                    fila[4] = cargo;
                    fila[5] = fecha_contrato;
                    fila[6] = sueldo_formateado;
                    modelo.addRow(fila);
                }
                
            }
            this.jTableListadoEmpleados.setModel(modelo);
            this.alinearColumnaTabla(jTableListadoEmpleados, 3, SwingConstants.CENTER);
            this.alinearColumnaTabla(jTableListadoEmpleados, 5, SwingConstants.RIGHT);
            this.alinearColumnaTabla(jTableListadoEmpleados, 6, SwingConstants.RIGHT);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Problemas de conexión con la base de datos.","Mensajes",JOptionPane.ERROR_MESSAGE);
        } 
    }
    
    public void cargarTablaEmpleados(int id){
        try {
            ArrayList<Empleado> empleados = EC.readAll();
            ArrayList<Cargo> cargos = CC.readAll();
            DefaultTableModel modelo = new DefaultTableModel();
            modelo.addColumn("Rut");
            modelo.addColumn("Nombre");
            modelo.addColumn("Email");
            modelo.addColumn("Genero");
            modelo.addColumn("Cargo");
            modelo.addColumn("Fecha Contrato");
            modelo.addColumn("Sueldo");
            for(Empleado e: empleados){
                if(e.getId_cargo() == id){
                    Object fila[] = new Object[7];
                    fila[0] = e.getRut();
                    fila[1] = e.getNombre() + " " + e.getApellido();
                    fila[2] = e.getEmail();
                    fila[3] = e.getGenero().toUpperCase();
                    String cargo = "";
                    for(Cargo c: cargos){
                        if(c.getId_cargo() == e.getId_cargo()){
                            cargo = c.getDescripcion();
                        }
                    }
                    fila[4] = cargo;
                    fila[5] = new SimpleDateFormat("dd-MM-yyyy").format(e.getFecha_contrato());
                    fila[6] = new DecimalFormat("$ #,##0").format(e.getSueldo());
                    modelo.addRow(fila);
                }
            }
            this.jTableListadoEmpleados.setModel(modelo);
            this.alinearColumnaTabla(jTableListadoEmpleados, 3, SwingConstants.CENTER);
            this.alinearColumnaTabla(jTableListadoEmpleados, 5, SwingConstants.RIGHT);
            this.alinearColumnaTabla(jTableListadoEmpleados, 6, SwingConstants.RIGHT);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Problemas de conexión con la base de datos.","Mensajes",JOptionPane.ERROR_MESSAGE);
        } 
    }
   
    
    private void alinearColumnaTabla(JTable tabla, int columna, int alineacion){
        DefaultTableCellRenderer alinearTabla = new DefaultTableCellRenderer();
        alinearTabla.setHorizontalAlignment(alineacion);
        tabla.getColumnModel().getColumn(columna).setCellRenderer(alinearTabla);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonEliminarEmpleado;
    private javax.swing.JButton jButtonReestablecerTablaEmpleados;
    private javax.swing.JComboBox<String> jComboBoxListadoCargos;
    private javax.swing.JLabel jLabelFiltroCargos;
    private javax.swing.JLabel jLabelFiltroTextos;
    private javax.swing.JPanel jPanelFiltros;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableListadoEmpleados;
    private javax.swing.JTextField jTextFieldFiltro;
    // End of variables declaration//GEN-END:variables
}
