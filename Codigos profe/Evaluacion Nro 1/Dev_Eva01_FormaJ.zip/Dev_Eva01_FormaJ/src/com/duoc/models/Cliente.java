package com.duoc.models;

public class Cliente {

    private String rut;
    private String nombre;
    private String apellido;
    private String fono;
    private char tipo_cliente;
    private Vehiculo vehiculo;

    public Cliente() {
    }

    public Cliente(String rut, String nombre, String apellido, String fono, char tipo_cliente) {
        this.rut = rut;
        this.nombre = nombre;
        this.apellido = apellido;
        this.fono = fono;
        this.tipo_cliente = tipo_cliente;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getFono() {
        return fono;
    }

    public void setFono(String fono) {
        this.fono = fono;
    }

    public char getTipo_cliente() {
        return tipo_cliente;
    }

    public void setTipo_cliente(char tipo_cliente) {
        this.tipo_cliente = tipo_cliente;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }
    
    public boolean comprarVehiculo(Vehiculo vehiculo){
        if(this.vehiculo == null){
            if(vehiculo.isVendido() == false){
                double valorVehiculo = vehiculo.getPrecio() * (1 - vehiculo.obtenerDescuento(tipo_cliente));
                vehiculo.setPrecio(valorVehiculo);
                vehiculo.setVendido(true);
                this.vehiculo = vehiculo;
                return true;
            }
        }
        return false;
    }
    
    public String informacionCliente(){
        String informacion = "*******************************************"+
                "\nRut           : " + rut + 
                "\nNombre        : " + nombre + " " + apellido +
                "\nFono          : " + fono + 
                "\nTipo Cliente  : " + ((tipo_cliente == 'N' || tipo_cliente == 'n')?"Nuevo":"Antiguo");
        
        if(this.vehiculo != null){
            informacion += "\nDatos Vehículo comprado\n" + vehiculo.informacionVehiculo();
        }
        else{
            informacion += "\nSin vehículo comprado aún.";
        }
        
        return informacion;
        
    }
    
}
