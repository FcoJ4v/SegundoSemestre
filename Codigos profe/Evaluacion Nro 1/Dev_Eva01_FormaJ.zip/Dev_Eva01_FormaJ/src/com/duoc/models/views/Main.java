package com.duoc.models.views;

import com.duoc.models.Cliente;
import com.duoc.models.Vehiculo;

public class Main {
    
    public static void main(String[] args) {
        
        Vehiculo v1 = new Vehiculo("JJKG56", "458", "Ferrari", 2020, 150000000, 0, "Bencina");
        Vehiculo v2 = new Vehiculo("SPFG47", "Celerio", "Suzuki", 2022, 9000000, 0, "Bencina");
        Cliente c1 = new Cliente("111-1", "Armando", "Mochas", "+5695555555", 'N');
        Cliente c2 = new Cliente("222-2", "Elba", "lazo", "+56912345678", 'A');
        Cliente c3 = new Cliente("333-3", "Elsa", "Pato", "+5699994567", 'N');
        
        System.out.println(v1.informacionVehiculo());
        System.out.println(v2.informacionVehiculo());
        
        System.out.println(c1.comprarVehiculo(v1));
        System.out.println(c2.comprarVehiculo(v1));
        System.out.println(c3.comprarVehiculo(v2));
        
        System.out.println(c1.informacionCliente());
        System.out.println(c2.informacionCliente());
        System.out.println(c3.informacionCliente());
        
                
    }
    
}
