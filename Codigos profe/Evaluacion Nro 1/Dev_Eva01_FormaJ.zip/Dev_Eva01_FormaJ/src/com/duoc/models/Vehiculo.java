package com.duoc.models;

import java.text.DecimalFormat;

public class Vehiculo {
    
    private String patente;
    private String modelo;
    private String fabricante;
    private int año_fabricacion;
    private double precio;
    private double kilometraje;
    private String combustible;
    private boolean vendido = false;

    public Vehiculo() {
    }

    public Vehiculo(String patente, String modelo, String fabricante, int año_fabricacion, double precio, double kilometraje, String combustible) {
        this.patente = patente;
        this.modelo = modelo;
        this.fabricante = fabricante;
        this.año_fabricacion = año_fabricacion;
        this.precio = precio;
        this.kilometraje = kilometraje;
        this.combustible = combustible;
    }

    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public int getAño_fabricacion() {
        return año_fabricacion;
    }

    public void setAño_fabricacion(int año_fabricacion) {
        this.año_fabricacion = año_fabricacion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public double getKilometraje() {
        return kilometraje;
    }

    public void setKilometraje(double kilometraje) {
        this.kilometraje = kilometraje;
    }

    public String getCombustible() {
        return combustible;
    }

    public void setCombustible(String combustible) {
        this.combustible = combustible;
    }

    public boolean isVendido() {
        return vendido;
    }

    public void setVendido(boolean vendido) {
        this.vendido = vendido;
    }
    
    public double obtenerDescuento(char tipo_cliente){
        double descuento= 0;
        if(tipo_cliente == 'N' || tipo_cliente == 'n'){
            descuento= 0.2;
        }
        else{
            descuento = 0.1;
            if(precio > 1500000){
                descuento += 0.05;
            }
        }
        return descuento;
    }
    
    public String recomendaciones(){
        String recomendacion = "";
        switch(combustible){
            case "Diesel" : recomendacion = "Considere revisar inyectores cada 20.000 kms"; break;
            case "Bencina" : recomendacion = "Nunca pero nunca le pongas Diesel o matarás a tu papurri papá"; break;
            case "Eléctrico" : recomendacion = "Carga el auto por las noches"; break;
        }
        return recomendacion;
    }
    
    public String informacionVehiculo(){
        DecimalFormat formatoPrecio = new DecimalFormat("$#,##0");
        String informacion = "------------------------------------------" +
                "\nPatente        : " + patente +
                "\nFabricante     : " + fabricante + 
                "\nModelo         : " + modelo +
                "\nAño Fabricación: " + año_fabricacion + 
                "\nKilometraje    : " + kilometraje + "kms." + 
                "\nPrecio         : " + formatoPrecio.format(precio) +
                "\nCombustible    : " + combustible +
                "\nRecomendaciones: " + recomendaciones() +
                "\nEstado         : " + ((vendido)?"Vendido":"Disponible");
        
        return informacion;
    } 
    
    
    
    
}
