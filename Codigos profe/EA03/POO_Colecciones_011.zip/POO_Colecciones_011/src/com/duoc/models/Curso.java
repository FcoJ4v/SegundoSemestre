package com.duoc.models;

import java.util.ArrayList;

public class Curso {
    
    private String codigo;
    private String nombre;
    private ArrayList<Alumno> listaAlumnos = new ArrayList<>();

    public Curso() {
    }

    public Curso(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Alumno> getListaAlumnos() {
        return listaAlumnos;
    }

    public void setListaAlumnos(ArrayList<Alumno> listaAlumnos) {
        this.listaAlumnos = listaAlumnos;
    }
    
    /**
     * Este método permite inscribir a un nuevo alumno a el curso. Antes de 
     * registrar valida que el alumno que se desea inscribir no este registrado
     * previamente.
     * 
     * @param nuevo Alumno
     * @return boolean
     * @author Elvis Tek
     * @since 30th, septembre 2022
     * 
     */
    public boolean inscribirAlumno(Alumno nuevo){
//        for(Alumno a: listaAlumnos){
//            if(a.getRut().equals(nuevo.getRut())){
//                return false;
//            }
//        }    
        if(buscarAlumno(nuevo.getRut()) == null){
            listaAlumnos.add(nuevo);
            return true;
        }
        return false;        
    }
    
    
    public boolean desertarCurso(String rut){
        Alumno a = buscarAlumno(rut);
        if(a != null){
            listaAlumnos.remove(a);
            return true;
        }
        return false;
    }
    
    public Alumno buscarAlumno(String rut){
        for(Alumno a: listaAlumnos){
            if(a.getRut().equals(rut)){
                return a;
            }
        }
        return null;
    }
    
    public double promedioGeneral(){
        if(!listaAlumnos.isEmpty()){
            double acumPromedios = 0;
            for(Alumno a: listaAlumnos){
                acumPromedios += a.generarPromedio();
            }
            return Math.round(acumPromedios / listaAlumnos.size() * 10.0) / 10.0;
        }
        return 0.0;
    }
    
    public String informacionCurso(){
        String listadoAlumnos = (listaAlumnos.isEmpty()? "Sin alumnos registrados": "");
        for(Alumno a: listaAlumnos){
            listadoAlumnos += a.informacionAlumno();
        }
        return "CURSO " + codigo + " | " + nombre + "\n" + 
                "Promedio General: " + promedioGeneral() + "\n\n" +
                "Listado Alumnos \n" + listadoAlumnos;
    }
    
}
