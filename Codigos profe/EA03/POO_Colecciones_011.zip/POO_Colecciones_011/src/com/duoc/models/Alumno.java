package com.duoc.models;

public class Alumno {
    
    private String rut;
    private String nombre;
    private String apellido;
    private String email;
    private double[] notas;

    public Alumno() {
    }

    public Alumno(String rut, String nombre, String apellido, double[] notas) {
        this.rut = rut;
        this.nombre = nombre;
        this.apellido = apellido;
        this.notas = notas;
        generarEmail();
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEmail() {
        this.generarEmail();
        return email;
    }

    //Este método según la descripción podría ser eliminado para impedir que 
    //se ingrese manualmente el email
    private void setEmail(String email) {
        this.email = email;
    }

    public double[] getNotas() {
        return notas;
    }

    public void setNotas(double[] notas) {
        this.notas = notas;
    }
    
    /**
     * Este método nos permite crear el email de un alumno a partir de 
     * las 3 primeras letras del nombre en caso que el largo del nombre 
     * sea mayor o igual a 3, unido con el apellido y el dominio de la
     * institución (dominio: @duocuc.cl)
     * 
     * @return void
     * @version 1.0
     * @author Christian Sarmiento
     * @since 27th, september 2022
     */
    private void generarEmail(){
        String dominio = "@duocuc.cl";
        String nombreAux = nombre;
        if(nombre.length() >= 3){
            nombreAux = nombre.substring(0, 3);
        }
        this.email = (nombreAux + "." + apellido + dominio).toLowerCase();
    }
    
    /**
     * Este método permite obtener el promedio final del alumno. 
     * El método recorre el arreglo de notas sumando cada nota,
     * para luego dividir por la cantidad de notas ingresadas.
     * Si el alumno no registra notas el promedio será un 1.0.
     * 
     * @return double
     * @version 1.0
     * @author Christian Sarmiento
     * @since 30th, septembre 2022
     */
    public double generarPromedio(){
        double acumNotas = 0;
        if(notas.length > 0){
            for(int i=0; i < notas.length; i++){
                acumNotas += notas[i];
            }
            return Math.round(acumNotas / notas.length * 10.0) / 10.0;
        }
        return 1.0;
    }
    
    /**
     * 
     * @return String
     * @author Christian Sarmiento
     * @since 30th, septembre 2022
     */
    public String informacionAlumno(){
        return "*******************************************\n" +
                "Rut         : " + rut + "\n" +
                "Nombre      : " + nombre + " " + apellido + "\n" + 
                "Email       : " + getEmail() + "\n" + 
                "Promedio    : " + this.generarPromedio() + "\n" + 
                "Estado      : " + ((generarPromedio() >= 3.95)?"Aprobado":"Reprobado") + "\n";
    }
    
    
}
