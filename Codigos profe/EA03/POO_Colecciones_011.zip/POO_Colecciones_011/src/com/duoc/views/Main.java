package com.duoc.views;

import com.duoc.models.Alumno;
import com.duoc.models.Curso;
//import com.duoc.models.*;

public class Main {
    
    public static void main(String[] args) {
        
        Curso curso = new Curso("PGY2121-011","Desarrollo de Software de Escritorio");
        
        double[] notasA1 = {5,6,7,3};
        Alumno a1 = new Alumno("15151515-5","Elba","Lazo",notasA1);
        
        double[] notasA2 = {3.4,2.1,4.0,3.5};
        Alumno a2 = new Alumno("12121212-5","Armando","Mochas",notasA2);
        
        double[] notasA3 = {2.1,4.5,5.5,7};
        Alumno a3 = new Alumno("16161645-K","Alan","Brito",notasA3);

        System.out.println((curso.inscribirAlumno(a1)?"Inscrito":"Ya esta registrado"));
        System.out.println((curso.inscribirAlumno(a1)?"Inscrito":"Ya esta registrado"));
        System.out.println((curso.inscribirAlumno(a2)?"Inscrito":"Ya esta registrado"));
        System.out.println((curso.inscribirAlumno(a3)?"Inscrito":"Ya esta registrado"));
        
        System.out.println(curso.informacionCurso());
        
        
    }
    
}
