package com.duoc.views;

import com.duoc.models.Administrativo;
import com.duoc.models.Alumno;
import com.duoc.models.Docente;
import com.duoc.models.Persona;
import com.duoc.models.Sede;

//import com.duoc.models.*;

public class Main {

    public static void main(String[] args) {
        Sede sede = new Sede("San Joaqu�n");
        Alumno a1 = new Alumno("111111-1", "Elba", "Lazo", "15-10-1998", "Ingenieri�a Informatica", 4, 'D');
        Alumno a2 = new Alumno("121212-2", "Elsa", "Capunta", "15-10-1998", "Analista Programador", 3, 'D');
        Alumno a3 = new Alumno("131313-3", "Alan", "Brito", "15-10-1998", "Ingenieri�a Informatica", 7, 'D');
        Alumno a4 = new Alumno("141414-4", "Armando", "Casas", "15-10-1998", "Ingenieri�a Automotriz", 2, 'D');
        Alumno a5 = new Alumno("161616-6", "Luz", "Rojas", "15-10-1998", "Enfermer�a", 3, 'D');               
        Docente d1 = new Docente("101010-1", "Armando", "Mochas", "05-08-1980", "03-03-2018", "Ingeniero Informatico");
        Docente d2 = new Docente("171717-7", "Elvis", "Tek", "05-08-1980", "03-03-2018", "Ingeniero Agr�nomo");  
        Administrativo ad1 = new Administrativo("9999-9", "Rosamel", "Fierro", "05-80-1967", "Director de Carrera");
        
        System.out.println(sede.ingresarPersona(a1));
        System.out.println(sede.ingresarPersona(a2));
        System.out.println(sede.ingresarPersona(a1));
        System.out.println(sede.ingresarPersona(d1));
        System.out.println(sede.ingresarPersona(a3));
        System.out.println(sede.ingresarPersona(ad1));
        System.out.println(sede.ingresarPersona(a4));
        System.out.println(sede.ingresarPersona(d2));
        System.out.println(sede.ingresarPersona(d2));
        System.out.println(sede.ingresarPersona(a5));
        
        for(Persona p: sede.getListadoPersonas()){
            System.out.println(p.saludar());
        }
        
        System.out.println("*****************************************");
        for (Alumno a : sede.listadoAlumnos()) {
            System.out.println(a);
        }
        
        
        
    }
    
}
