package com.duoc.models;

public class Docente extends Empleado{
    
    private String titulo;
    private boolean contratado = true;

    public Docente() {
    }

    public Docente(String rut, String nombre, String apellido, String fecha_nacimiento, String fecha_ingreso, String titulo) {
        super(rut, nombre, apellido, fecha_nacimiento, fecha_ingreso);
        this.titulo = titulo;
    }

    

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public boolean isContratado() {
        return contratado;
    }

    public void setContratado(boolean contratado) {
        this.contratado = contratado;
    }
    
    @Override
    public String saludar(){
        String informacion = super.saludar() + ", soy " + titulo;
        if(contratado){
            informacion += " y actualmente estoy dictando clases.";
        }
        else{
            informacion += " y actualmente estoy desempleado.";
        }
        return informacion;
    }
    
    public double calcularSueldo(int valorHora, double horasTrabajadas){
        return valorHora * horasTrabajadas + SUELDO_BASE;
    }
    
    @Override
    public void crearEmail(){
        String nombreAux = nombre;
        if(nombre.length() >= 3){
            nombreAux = nombre.substring(0, 3);
        }
        email = (nombreAux + "." + apellido + DOMINIO_DOCENTE).toLowerCase();        
    }
    
    @Override
    public String toString(){
        String informacion = "-----------------------------------------" + 
                "\nRut            : " + rut + 
                "\nNombre         : " + nombre + " " + apellido +
                "\nEmail          : " + email +
                "\nTitulo         : " + titulo + 
                "\nEstado         : " + ((contratado)?"Contratado (desde " + fecha_ingreso + ")":"Desempleado") + "\n";
        
        return informacion;
    }
    
    
    
    
}
