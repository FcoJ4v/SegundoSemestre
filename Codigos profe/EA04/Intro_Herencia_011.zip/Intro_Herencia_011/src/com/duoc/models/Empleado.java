package com.duoc.models;

public abstract class Empleado extends Persona{
    
    protected String fecha_ingreso;

    public Empleado() {
    }

    public Empleado(String rut, String nombre, String apellido, String fecha_nacimiento, String fecha_ingreso) {
        super(rut, nombre, apellido, fecha_nacimiento);
        this.fecha_ingreso = fecha_ingreso;
    }

    public String getFecha_ingreso() {
        return fecha_ingreso;
    }

    public void setFecha_ingreso(String fecha_ingreso) {
        this.fecha_ingreso = fecha_ingreso;
    }

    
}
