package com.duoc.models;

import java.util.ArrayList;

public class Sede {
    
    private String nombre;
    private ArrayList<Persona> listadoPersonas = new ArrayList<>();

    public Sede(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Persona> getListadoPersonas() {
        return listadoPersonas;
    }

    public void setListadoPersonas(ArrayList<Persona> listadoPersonas) {
        this.listadoPersonas = listadoPersonas;
    }
    
    //M�todos CUSTOM
    public boolean ingresarPersona(Persona p){
        if(buscarPersona(p.getRut()) == null){
            listadoPersonas.add(p);
            return true;
        }
        return false;
    }
    
    public boolean salirPersona(String rut){
        Persona p = buscarPersona(rut);
        if(p != null){
            listadoPersonas.remove(p);
            return true;
        }
        return false;
    }
    
    public Persona buscarPersona(String rut){
        for(Persona p: listadoPersonas){
            if(p.getRut().equals(rut)){
                return p;
            }
        }
        return null;
    }
    
    public ArrayList<Alumno> listadoAlumnos(){
        ArrayList<Alumno> alumnos = new ArrayList<>();
        for(Persona p: listadoPersonas){
            if(p instanceof Alumno){
                alumnos.add((Alumno)p);
            }
        }
        return alumnos;
    }
    
    public ArrayList<Docente> listadoDocentes(){
        ArrayList<Docente> docentes = new ArrayList<>();
        for(Persona p: listadoPersonas){
            if(p instanceof Docente){
                docentes.add((Docente)p);
            }
        }
        return docentes;
    }
    
    public ArrayList<Administrativo> listadoAdministrativos(){
        ArrayList<Administrativo> administrativos = new ArrayList<>();
        for(Persona p: listadoPersonas){
            if(p instanceof Administrativo){
                administrativos.add((Administrativo)p);
            }
        }
        return administrativos;
    }
    
    
    
    
    
    
}
