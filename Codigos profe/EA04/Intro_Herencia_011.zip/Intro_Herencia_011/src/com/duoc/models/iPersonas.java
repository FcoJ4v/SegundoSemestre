package com.duoc.models;

import java.text.DecimalFormat;

public interface iPersonas {
    
    //Declaraci�n de constantes para todo quien implemente...
    public final String DOMINIO_ALUMNOS = "@duocuc.cl";
    public final String DOMINIO_DOCENTE = "@profesor.duoc.cl";
    public final String DOMINIO_ADMINISTRATIVO = "@duoc.cl";
    public final int SUELDO_BASE = 555000;
    public final DecimalFormat FORMATO_MONEDA = new DecimalFormat("#,##0");
    
    
    //Definici�n de m�todo que deben ser programados por todos quienes implementen la Interface
    public String saludar();
    
    public void crearEmail();
    
}
