package com.duoc.models;

public final class Alumno extends Persona {
    
    private String carrera;
    private int semestre;
    private char jornada;
    private boolean egresado = false;
    
    public Alumno(){
        
    }

    public Alumno(String rut, String nombre, String apellido, String fecha_nacimiento, String carrera, int semestre, char jornada) {
        super(rut, nombre, apellido, fecha_nacimiento);
        this.carrera = carrera;
        this.semestre = semestre;
        this.jornada = jornada;
        crearEmail();
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    public char getJornada() {
        return jornada;
    }

    public void setJornada(char jornada) {
        this.jornada = jornada;
    }

    public boolean isEgresado() {
        return egresado;
    }

    public void setEgresado(boolean egresado) {
        this.egresado = egresado;
    }
    
    @Override
    public String saludar(){
        String[] nombreSemestre = {"1er","2do","3er","4to","5to","6to","7mo","8vo"};
        String saludar = super.saludar();
        if(!egresado){
            saludar += " estoy estudiando la carrera de " + 
                carrera + ", soy de la jornada " + ((jornada == 'D')?"diurna":"vespertina") + 
                " y voy en el " + nombreSemestre[semestre-1] + " semestre.";
        }
        else{
            saludar += " y egres� de la carrera " + carrera + ".";
        }
        return saludar;
        
    }
    
    @Override
    public void crearEmail(){
        this.email = (nombre + "." + apellido + DOMINIO_ALUMNOS).toLowerCase();
    }
        
    public void estudiar(){
        if(carrera.contains("Analista") && semestre >= 5){
            egresado = true;
            return;
        }
        if(carrera.contains("Ingenieria") && semestre >= 8){
            egresado = true;
            return;
        }
        semestre++;        
    }

    @Override
    public String toString() {
        String informacion = "-----------------------------------------" + 
                "\nRut            : " + rut + 
                "\nNombre         : " + nombre + " " + apellido +
                "\nEmail          : " + email +
                "\nCarrera        : " + carrera;
        if(egresado){
            informacion += "\nEstado         : Egresado"; 
        }
        else{
            informacion += "\nSemestre       : " + semestre +
                    "\nJornada        : " + ((jornada == 'D')?"Diurno":"Vespertino") + "\n"; 
        }
        
        return informacion;
    }
    
    
        
    
    
    
    
}
