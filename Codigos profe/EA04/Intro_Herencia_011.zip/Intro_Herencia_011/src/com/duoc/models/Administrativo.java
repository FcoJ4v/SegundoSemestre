package com.duoc.models;


public class Administrativo extends Persona{
    
    private String cargo;

    public Administrativo() {
    }

    public Administrativo(String rut, String nombre, String apellido, String fecha_nacimiento, String cargo) {
        super(rut, nombre, apellido, fecha_nacimiento);
        this.cargo = cargo;
        crearEmail();
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
    @Override
    public String saludar(){
        return super.saludar() + " y soy " + cargo;
    }
    
    @Override
    public void crearEmail(){
        email = (nombre.substring(0, 1) + apellido + "@duoc.cl").toLowerCase(); 
    }
    
    public double obtenerSueldo(){
        double sueldo = 0;
        if(cargo.contains("Director")){
            sueldo = SUELDO_BASE * 10;
        }
        else if(cargo.contains("Coordinador")){
            sueldo = SUELDO_BASE * 4;
        }
        else if(cargo.contains("Secretariado")){
            sueldo = SUELDO_BASE * 3;
        }
        else{
            sueldo = SUELDO_BASE * 2 ;
        }
        return sueldo;
    }
    
    @Override
    public String toString(){
        String informacion = "-------------------------------------" + 
                "\nRut           : " + rut +
                "\nNombre        : " + nombre + " " + apellido +
                "\nEmail         : " + email +
                "\nCargo         : " + cargo +
                "\nSueldo        : $" + FORMATO_MONEDA.format(obtenerSueldo()) + "\n";
        return informacion;
    }
    
    
    
}
