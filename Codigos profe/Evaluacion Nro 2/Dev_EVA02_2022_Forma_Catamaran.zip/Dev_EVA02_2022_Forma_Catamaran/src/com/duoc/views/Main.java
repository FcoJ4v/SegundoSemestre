package com.duoc.views;

import com.duoc.models.Catamaran;
import com.duoc.models.Pasajero;
import com.duoc.models.Persona;
import com.duoc.models.Tripulante;

public class Main {

    public static void main(String[] args) {
        
        Catamaran a = new Catamaran("Noruega",150);
        
        Tripulante tp1 = new Tripulante("15.151.515-5", "Aquiles", "Baeza", 35, 'P');
        Tripulante tp2 = new Tripulante("12.139.145-9", "Armando", "Mochas", 42, 'P');
        Tripulante tp3 = new Tripulante("18.177.767-K", "Susana", "Oria", 30, 'A');
        Tripulante tp4 = new Tripulante("20.146.456-2", "Elba", "Lazo", 23, 'A');
        
        Pasajero p1 = new Pasajero("5.496.456-5", "Esteban", "Dido", 65, "Laguna San Rafael", 'S');
        Pasajero p2 = new Pasajero("5.432.456-6", "Iloveny", "Flores", 63, "Cabo de Hornos", 'N');
        Pasajero p3 = new Pasajero("12.879.789-k", "Sacaría", "Flores del Campo", 43, "Laguna San Rafael", 'N');
        Pasajero p4 = new Pasajero("15.335.145-6", "Alan", "Brito", 40, "Cabo de Hornos", 'S');
        Pasajero p5 = new Pasajero("18.456.123-3", "Rosamel", "Fierro", 32, "Laguna San Rafael", 'N');
        Pasajero p6 = new Pasajero("18.123.793-4", "Elsa", "Capunta", 30, "Cabo de Hornos", 'N');
        Pasajero p7 = new Pasajero("20.145.763-8", "Luz", "Rojas", 23, "Cabo de Hornos", 'S');
        
        
        System.out.println("REGISTRANDO PERSONAS EN EL BUS...");
        System.out.println(a.registrarPersona(tp1));
        System.out.println(a.registrarPersona(tp2));
        System.out.println(a.registrarPersona(tp3));
        System.out.println(a.registrarPersona(tp4));
        System.out.println(a.registrarPersona(p1));
        System.out.println(a.registrarPersona(p2));
        System.out.println(a.registrarPersona(p3));
        System.out.println(a.registrarPersona(p4));
        System.out.println(a.registrarPersona(p5));
        System.out.println(a.registrarPersona(p6));
        System.out.println(a.registrarPersona(p7));
        
        System.out.println("********************************************************************");
        System.out.println("DETALLE DE LAS PERSONAS EN EL CATAMARAN");
        for(Persona p: a.getPersonas())
        {
            System.out.println(p.mostrarInformacion());
        }
        
        System.out.println("*********************************************************************");
        System.out.println("Trataremos de bajar a un par de personas...");
        System.out.println(a.bajarPersona("12.139.145-9"));
        System.out.println(a.bajarPersona("20.145.763-8"));
        System.out.println("**********************************************************************");
        System.out.println("Cuantos pasajeros quedan después de bajar a Luz Roja");
        System.out.println(a.listadoPasajeros().size());
        
        
        
               
        
        
    }
    
}
