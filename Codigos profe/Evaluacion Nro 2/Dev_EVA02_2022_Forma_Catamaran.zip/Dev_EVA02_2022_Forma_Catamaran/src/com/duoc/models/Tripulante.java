package com.duoc.models;

public final class Tripulante extends Persona{

    private char cargo;

    public Tripulante() {
    }

    public Tripulante(String rut, String nombre, String apellido, int edad, char cargo) {
        super(rut, nombre, apellido, edad);
        this.cargo = cargo;
    }

    public char getCargo() {
        return cargo;
    }

    public void setCargo(char cargo) {
        this.cargo = cargo;
    }    
    
    /**
     *  Este m�todo debe entregar la siguiente informaci�n:
     *  Tripulante: Capit�n Andr�s Bello - a.bello@tatam.com
     * 
     * @return String
     */
    @Override
    public String mostrarInformacion() {
        String funcion = "";
        if(cargo == 'A')
        {
            funcion = "Asistente";
        }
        else
        {
            funcion = "Capit�n";
        }
        return this.getClass().getSimpleName() + ": " + funcion + " " + nombre + " " + apellido + " - " + generarEmail();
    }
    
    /**
     *  Este m�todo retorna el email de cada tripulante. Para ello considerar el siguiente modelo: 
     *  primera letra del nombre + �.� + apellido + �@� + nombre_compa�ia + �.cl�
     * @return String
     */
    public String generarEmail(){
        return (nombre.substring(0,1) + "." + apellido + "@" + NOMBRE_COMPA�IA + ".cl").toLowerCase();
    }
    
}
