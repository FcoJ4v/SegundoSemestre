package com.duoc.models;

import java.util.ArrayList;

public class Catamaran {
    private String pais_fabricacion;
    private int cantidad_max_personas;
    private ArrayList<Persona> personas = new ArrayList<>();

    public Catamaran() {
    }

    public Catamaran(String pais_fabricacion, int cantidad_max_personas) {
        this.pais_fabricacion = pais_fabricacion;
        this.cantidad_max_personas = cantidad_max_personas;
    }

    public String getPais_fabricacion() {
        return pais_fabricacion;
    }

    public void setPais_fabricacion(String pais_fabricacion) {
        this.pais_fabricacion = pais_fabricacion;
    }

    public int getCantidad_max_personas() {
        return cantidad_max_personas;
    }

    public void setCantidad_max_personas(int cantidad_max_personas) {
        this.cantidad_max_personas = cantidad_max_personas;
    }

    public ArrayList<Persona> getPersonas() {
        return personas;
    }

    public void setPersonas(ArrayList<Persona> personas) {
        this.personas = personas;
    }

    
    /**
     * Este método deberá retornar un TRUE si la persona no está en el catamarán y puede ser registrada y FALSE si ya está registrada. La búsqueda debe ser según el rut.
     * 
     * @param p Persona
     * @return boolean
     */
    public boolean registrarPersona(Persona p){
        if(personas.size() < cantidad_max_personas){
            if(buscarPersona(p.getRut()) == null)
            {
                personas.add(p);
                return true;
            }
        }        
        return false;
    }
    
    /**
     * Este método retornará TRUE o FALSE según si se bajó o no el PASAJERO indicado. Importante acotar que solo se pueden bajar personas que sean pasajeros. 
     * Los tripulantes no se ven afectados por este método.
     * 
     * @param rut String
     * @return boolean
     */
    public boolean bajarPersona(String rut){
        Persona p = buscarPersona(rut);
        if(p != null)
        {
            if(p instanceof Pasajero)
            {
                personas.remove(p);
                return true;
            }
        }
        return false;
    }
    
    /**
     *  Este método debe retornar una persona que debe ser buscada por su rut. Puede ser un pasajero o piloto el resultado buscado.
     * 
     * @param rut String
     * @return Persona
     */
    public Persona buscarPersona(String rut){
        for(Persona p: personas)
        {
            if(p.getRut().equals(rut))
            {
                return p;
            }
        }
        return null;
    }
    
    /**
     * Este método debe retornar una colección con todos los pasajeros que hay registrados
     * @return ArrayList
     */
    public ArrayList<Pasajero> listadoPasajeros(){
        ArrayList<Pasajero> pasajeros = new ArrayList<>();
        for(Persona p: personas)
        {
            if(p instanceof Pasajero)
            {
                pasajeros.add((Pasajero)p);
            }
        }
        return pasajeros;
    }
    
    
}
