package com.duoc.models;

public interface iCalculable {
    
    public final double CARGO_PASAJE_SALON_VIP = 0.4;
    public final double DESCUENTO_PASAJE_3RA_EDAD = 0.5;
    public final double DESCUENTO_PASAJE_TURISTA = 0.2;
    public final String NOMBRE_COMPAÑIA = "SCORUPI";
    
    public String mostrarInformacion();
    
}
