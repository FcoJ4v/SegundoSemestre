package com.duoc.models;

import java.text.DecimalFormat;

public class Pasajero extends Persona{
    
    private String destino;
    private char categoria;

    public Pasajero() {
    }

    public Pasajero(String rut, String nombre, String apellido, int edad, String destino, char categoria) {
        super(rut, nombre, apellido, edad);
        this.destino = destino;
        this.categoria = categoria;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public char getCategoria() {
        return categoria;
    }

    public void setCategoria(char categoria) {
        this.categoria = categoria;
    }
    
    public double valorPasaje(){
        double valor = 0;
        switch (destino) {
            case "Laguna San Rafael" -> valor = 500000;
            case "lago Todos los Santos" -> valor = 250000;
            case "Lago Riñihue" -> valor = 350000;
            case "Lago General Carrera" -> valor = 450000;
            case "Rio Futaleufú" -> valor = 400000;
            case "Cabo de Hornos" -> valor = 600000;
        }
        
        //CARGO O DESCUENTO POR CATEGORIA
        if(categoria == 'S'){
            valor *= (1 + CARGO_PASAJE_SALON_VIP);
        }
        else {
            valor *= (1 - DESCUENTO_PASAJE_TURISTA);
        }
        
        if(edad >= 60){
            valor *= (1 - DESCUENTO_PASAJE_3RA_EDAD);
        }
        
        return valor;
    }

    @Override
    public String mostrarInformacion() {
        String tipo_pasajero = "Turista";
        if(categoria == 'S')
        {
            tipo_pasajero = "Pasajero Salon VIP";
        }
        return this.getClass().getSimpleName() + ": " + rut + " " + nombre + " " + apellido + " " + edad + " años | " + tipo_pasajero + " | Destino " + destino + " | Valor Pasaje: " + new DecimalFormat("$ #,##0").format(valorPasaje());
    }
    
}
