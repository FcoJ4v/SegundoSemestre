package cl.duoc.modelo;

public class Persona {

    //atributos
    //[visibilidad] + tipo_dato + identificador  [=valor_por_defecto] ;
    private String rut;
    private String nombre;
    private String apellido;
    private int edad;
    private char genero;
    private String nacionalidad;

    public Persona() {
    }

    public Persona(String rut, String nombre, String apellido, int edad, char genero, String nacionalidad) {
        this.rut = rut;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.genero = genero;
        this.nacionalidad = nacionalidad;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public char getGenero() {
        return genero;
    }

    public void setGenero(char genero) {
        this.genero = genero;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }    
    
    //métodos
    public String saludar(){
        return "Hola me llamo " + nombre + " " + apellido + " tengo " + edad + " años y soy " + nacionalidad;
    }
    
    public void cumplirAños(){
        //edad = edad + 1;
        //edad += 1;
        edad++;
    }

    
}
