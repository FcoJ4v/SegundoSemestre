package cl.duoc.cli;

import cl.duoc.modelo.Persona;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Main {
    
    //psvm + tab
    public static void main(String[] args) {
        
        Persona p1 = new Persona();
        p1.setRut("11111-1");
        p1.setNombre("Elba");
        p1.setApellido("Lazo");
        p1.setEdad(25);
        p1.setGenero('f');
        p1.setNacionalidad("Chilena");
        
        System.out.println(p1.saludar());
        
        Persona p2 = new Persona("2222-2","Armando","Casas",40,'m',"Chileno");
        
        JOptionPane.showMessageDialog(null, p2.saludar(), "Mensajes", JOptionPane.INFORMATION_MESSAGE);
        
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese su rut: ");
        String rut = sc.next();
        System.out.print("Ingrese su nombre: ");
        String nombre = sc.next();
        System.out.print("Ingrese su apellido: ");
        String apellido = sc.next();
        System.out.print("Ingrese su edad: ");
        int edad = sc.nextInt();
        System.out.print("Ingrese su genero [f|m|o]: ");
        char genero = sc.next().charAt(0);
        System.out.print("Ingrese su nacionalidad: ");
        String nacionalidad = sc.next();
        
        Persona p3 = new Persona(rut, nombre, apellido, edad, genero, nacionalidad);
        
        System.out.println(p3.saludar());
    }
    
}
