package cl.duoc.guia01;

import java.util.Scanner;

public class Ejercicio02 {
    
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        
        //final double PI = 3.1416;
        
        System.out.print("Ingrese el radio de la circunferencia: ");
        double radio = sc.nextDouble();
        
        //double area = PI * radio * radio;
        double area = Math.PI * Math.pow(radio, 2.0);
        
        System.out.printf("Area circunferencia: %.1f\n", area);
        
        
    }
    
}
