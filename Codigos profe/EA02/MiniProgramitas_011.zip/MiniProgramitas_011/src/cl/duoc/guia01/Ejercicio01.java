package cl.duoc.guia01;

import java.util.Scanner;

public class Ejercicio01 {
    
    public static void main(String[] args){
        //Declaramos objeto Scanner para la lectura de los datos v�a consola
        Scanner sc = new Scanner(System.in);
        
        //Se imprime mensaje con el dato que se necesita leer y almacenamos el dato
        System.out.print("Ingrese primer valor: ");
        int valor1 = sc.nextInt();
        System.out.print("Ingrese segundo valor: ");
        int valor2 = sc.nextInt();
        
        //Procesamos los datos sumandolos
        int resultado = valor1 + valor2;
        
        //Se imprime el resultado del proceso realizado
        System.out.println(valor1 + " + " + valor2 + " = " + resultado);
        
        
    }
    
}
