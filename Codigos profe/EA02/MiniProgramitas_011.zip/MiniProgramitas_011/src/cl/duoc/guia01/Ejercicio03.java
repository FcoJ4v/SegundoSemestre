package cl.duoc.guia01;

import java.util.Scanner;

public class Ejercicio03 {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Ingrese primer valor: ");
        int valor1 = sc.nextInt();
        System.out.print("Ingrese segundo valor: ");
        int valor2 = sc.nextInt();
        
        int suma = valor1 + valor2;
        int resta = valor1 - valor2;
        int producto = valor1 * valor2;
        double division = (double)valor1 / (double)valor2;
        
        System.out.println(valor1 + " + " + valor2 + " = " + suma);
        System.out.println(valor1 + " - " + valor2 + " = " + resta);
        System.out.println(valor1 + " * " + valor2 + " = " + producto);
        System.out.println(valor1 + " / " + valor2 + " = " + division);
       
    }
    
}
