package cl.duoc.guia01;

import java.util.Scanner;

public class Ejercicio07 {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Ingrese radio de la circunferencia: ");
        double radio = sc.nextDouble();
        
        double volumen = (4.0 / 3.0) * Math.PI * Math.pow(radio, 3.0);
        double area = 4 * Math.PI * Math.pow(radio, 2.0);
        
        System.out.printf("Radio  : %.1f\n",radio);
        System.out.printf("Volumen: %.1f\n",volumen);
        System.out.printf("Area   : %.1f\n",area);
    }
    
}
