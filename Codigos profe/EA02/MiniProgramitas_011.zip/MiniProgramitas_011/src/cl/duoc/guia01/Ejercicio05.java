package cl.duoc.guia01;

import java.util.Scanner;

public class Ejercicio05 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Convertidor Temperaturas V1.0");
        System.out.print("Ingrese temperatura [�C]: ");
        double celsius = sc.nextDouble();
        
        double fahrenheit = 9.0/5.0 * celsius + 32;
        
        System.out.println(celsius + "�C -> " + fahrenheit + "�F");
        
    }
    
}
