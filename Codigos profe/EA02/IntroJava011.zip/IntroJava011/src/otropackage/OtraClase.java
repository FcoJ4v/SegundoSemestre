package otropackage;

/**
 *
 * @author Cetecom
 */
public class OtraClase {
    
}
