package introjava011;

import java.util.Scanner;

public class IntroJava011 {

    public static void main(String[] args) {
        System.out.println("Hola mundo!!!");
        System.out.println("Mi nombre es Christian Sarmiento\ny seré su peor pesadilla...");
    
    
        //Variables Primitivas
        
        //Numéricas
        byte edad = 10;
        short valorHora = 10000;
        int sueldo = 5000000;
        long edadUniverso = 1236512431536145646L;
        float promedio = 5.6F;
        double porcentaje = 0.16;
        double _10 = 10;
        final double PI = 3.141592654;
        
        
        //Texto
        char letra = 'a';
        char otraLetra = 'a';
        
        //Si bien no es una variable todos la usan como tal
        String frase = "Hola loco como estai";
        String nombreCompleto = "Elba Lazo Perdido";
        String nombre_completo = "Armando Casas de Adobe";
        
        boolean respuesta = true;
        boolean isVivo = true;
        boolean isEgresado = false;
        
        System.out.println(nombreCompleto);
        
        System.out.println(frase + " " +  nombreCompleto);
        
        System.out.println("Hola me llamo " + nombreCompleto + " y tengo " + edad + " años");
        
        System.out.println(edad + Integer.parseInt("10"));
        
        System.out.printf("Hola me llamo %s y tengo %d años\n",nombreCompleto,edad);
        
        boolean _true = true;
        
        //Leer datos usando la consola...
        //edad = int(input("Ingrese su edad: "))
        //nombre = input("Ingrese su nombre: ")
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Ingresa tu nombre: ");
        String firstname = sc.next(); //la función next() es para leer una cadena de texto. Sin espacions
        System.out.print("Ingresa tu apellido: ");           
        String lastname = sc.next();
        System.out.print("Ingresa tu edad: ");
        int age = sc.nextInt(); //la función nextInt() es para leer números enteros
        System.out.print("Ingresa tu peso: ");
        double weight = sc.nextDouble();
        
        System.out.println("Bienvenido a esta maravillosa asignatura " + firstname + " " + lastname);
        
        
        
        
        
        
    }
    

}