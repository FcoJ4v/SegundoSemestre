package introjava011;

import java.util.Scanner;

public class Ejemplo01 {
    
    /**
     * Vamos a desarrollar un peque�o programa que nos permita
     * calcular el sueldo de un empleado a partir de las horas trabajadas
     * y su valor hora...
     */
    public static void main(String[] args) throws InterruptedException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Bienvenidos a CALCULADOR de SUELDO v1.0");
        System.out.print("Ingrese su nombre: ");
        String nombre = sc.next();
        System.out.print("Ingrese su apellido: ");
        String apellido = sc.next();
        System.out.print("Ingrese la cantidad de horas trabajadas en el mes: ");
        double horas = sc.nextDouble();
        System.out.print("Ingrese su valor hora: $");
        int valorHora = sc.nextInt();
        
        double sueldo = horas * valorHora;
        
        System.out.println("Sueldo a pagar...");
        Thread.sleep(3000);
        System.out.println("Empleado: " + nombre + " " + apellido);
        System.out.printf("Monto   : $%.0f\n",sueldo);
        //print(f"Monto : ${monto}")
        System.out.println("Muchas gracias por utilizar nuestros softwares...");
        
    }
    
}
