package com.duoc.clases;

import java.text.DecimalFormat;

public class CuentaBancaria {
    
    //Atributos
    private int nroCuenta;
    private int saldo;
    private boolean activa;

    //Constructores   
    public CuentaBancaria() {
    }

    public CuentaBancaria(int nroCuenta, int saldo, boolean activa) {
        this.nroCuenta = nroCuenta;
        this.saldo = saldo;
        this.activa = activa;
    }

    public int getNroCuenta() {
        return nroCuenta;
    }

    public void setNroCuenta(int nroCuenta) {
        this.nroCuenta = nroCuenta;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public boolean isActiva() {
        return activa;
    }

    public void setActiva(boolean activa) {
        this.activa = activa;
    }
    
    //Métodos CUSTOM
    public boolean girar(int monto){
        if(monto <= saldo && activa){
            saldo -= monto; //saldo = saldo - monto;
            return true;
        }
        return false;
    }
    
    public void depositar(int monto){
        saldo += monto;
    } 
    
    public String informacionCuenta(){
        DecimalFormat formato_saldo = new DecimalFormat("$ #,##0.00");
        String estado = "Bloqueada";
        if(activa){
            estado = "Activa";
        }
        return "Nro Cuenta    : " + nroCuenta +
                "\nDisponible    : " + formato_saldo.format(saldo) + 
                "\nEstado        : " + estado; 
    }

    
}
