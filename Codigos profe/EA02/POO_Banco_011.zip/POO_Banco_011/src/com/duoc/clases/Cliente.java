package com.duoc.clases;

public class Cliente {
    
    //Atributos
    private String rut;
    private String nombre;
    private String apellido;
    private CuentaBancaria cuenta;
    
    //Constructores
    public Cliente(){
        
    }

    public Cliente(String rut, String nombre, String apellido, CuentaBancaria cuenta) {
        this.rut = rut;
        this.nombre = nombre;
        this.apellido = apellido;
        this.cuenta = cuenta;
    }
    
    //Getters y Setters
    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public CuentaBancaria getCuenta() {
        return cuenta;
    }

    public void setCuenta(CuentaBancaria cuenta) {
        this.cuenta = cuenta;
    }
    
    //Métodos CUSTOM
    public boolean realizarGiro(int monto){
        return cuenta.girar(monto);
    }
    
    public void realizarDeposito(int monto){
        cuenta.depositar(monto);
    }
    
    public boolean transferir(Cliente otroCliente, int monto){
        if(cuenta.girar(monto)){
            otroCliente.realizarDeposito(monto);
            return true;
        }
        return false;
    }
    
    public String informacionCliente(){
        return "INFORMACION CLIENTE\n***********************************" + 
                "\nRut           : " + rut + 
                "\nNombre Cliente: " + nombre + " " + apellido +
                "\n" + cuenta.informacionCuenta() + "\n";
    }
    
    
}
