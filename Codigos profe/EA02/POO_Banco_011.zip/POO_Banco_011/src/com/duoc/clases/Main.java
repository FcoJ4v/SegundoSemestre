package com.duoc.clases;

import javax.swing.JOptionPane;


public class Main {
    
    public static void main(String[] args) {
        
        CuentaBancaria cuenta01 = new CuentaBancaria();
        cuenta01.setNroCuenta(123456578);
        cuenta01.setSaldo(150000);
        cuenta01.setActiva(true);
        Cliente cliente01 = new Cliente("12345678-K","Armando","Mochas",cuenta01);
        
        CuentaBancaria cuenta02 = new CuentaBancaria(15151515,500000,false);
        Cliente cliente02 = new Cliente("15456987-0","Elba","Lazo",cuenta02);
        
        System.out.println(cliente01.informacionCliente());
        System.out.println(cliente02.informacionCliente());
        
        System.out.println(cliente01.transferir(cliente02, 100000));
        
        System.out.println(cliente01.informacionCliente());
        System.out.println(cliente02.informacionCliente());
        
        cliente02.getCuenta().setActiva(true);
        System.out.println(cliente02.informacionCliente());
        
        JOptionPane.showMessageDialog(null, cliente02.informacionCliente(), "mensajes", JOptionPane.WARNING_MESSAGE);
        
        
        
    }
    
}
