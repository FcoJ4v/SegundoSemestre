package com.duoc.main;

import java.util.ArrayList;

public class Main {
    
    public static void main(String[] args) {
        
        //Arreglos
        int[] numeros = new int[5];
        numeros[0] = 10;
        numeros[1] = 15;
        numeros[2] = 20;
        numeros[3] = 35;
        numeros[4] = 20;
        //numeros[5] = 10; esto sería un error
        
        double[] edades = {10,20,40,50,35,25};
        
        double[] edadesAleatorias = new double[10];
        
        for(int i=0;i<edadesAleatorias.length;i++){
            edadesAleatorias[i] = Math.round(Math.random() * 100);
            System.out.printf("%.0f\n",edadesAleatorias[i]);
        }
        
        System.out.println("Tamaño del arreglo de edades: " + edadesAleatorias.length);
        
        
        //Colección
        ArrayList<Integer> listaEdades = new ArrayList<>();
        listaEdades.add(15);
        listaEdades.add(56);
        listaEdades.add(45);
        listaEdades.add(2, 29);
        listaEdades.add(16);
        
        for(Integer i: listaEdades){
            System.out.println(i);
        }
        
        System.out.println("Tamaño de la lista de edades: " + listaEdades.size());
        
        listaEdades.remove(1);
        
        for(Integer i: listaEdades){
            System.out.println(i);
        }
        
        System.out.println("Tamaño de la lista de edades: " + listaEdades.size());
        
    }
    
}
